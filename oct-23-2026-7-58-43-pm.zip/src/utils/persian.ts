/**
 * Persian language, date, calculation, and formatting utilities
 */

import { GradingFormulaConfig, TermGradeRecord } from '../types';

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const ARABIC_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

export function toPersianDigits(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === '') return '';
  const str = String(value);
  return str.replace(/\d/g, (d) => PERSIAN_DIGITS[parseInt(d, 10)]);
}

export function toEnglishDigits(value: string): string {
  if (!value) return '';
  let str = String(value);
  for (let i = 0; i < 10; i++) {
    str = str.replace(new RegExp(PERSIAN_DIGITS[i], 'g'), String(i));
    str = str.replace(new RegExp(ARABIC_DIGITS[i], 'g'), String(i));
  }
  return str.replace(/٫|،/g, '.');
}

/**
 * Convert Gregorian date to Persian Solar Hijri (Jalali)
 */
export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = (gy <= 1600) ? 0 : 979;
  gy -= (gy <= 1600) ? 621 : 1600;
  const gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
  return [jy, jm, jd];
}

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const PERSIAN_WEEKDAYS = [
  'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'
];

export function getTodayJalaliString(): string {
  const now = new Date();
  const [jy, jm, jd] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const sm = jm < 10 ? `0${jm}` : `${jm}`;
  const sd = jd < 10 ? `0${jd}` : `${jd}`;
  return `${jy}/${sm}/${sd}`;
}

export function getTodayJalaliFormatted(): {
  dateString: string;
  weekday: string;
  monthName: string;
  day: number;
  year: number;
  fullString: string;
} {
  const now = new Date();
  const [jy, jm, jd] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const weekday = PERSIAN_WEEKDAYS[now.getDay()];
  const monthName = PERSIAN_MONTHS[jm - 1];
  const dateString = `${jy}/${jm < 10 ? '0' + jm : jm}/${jd < 10 ? '0' + jd : jd}`;
  const fullString = `${weekday}، ${toPersianDigits(jd)} ${monthName} ${toPersianDigits(jy)}`;

  return {
    dateString,
    weekday,
    monthName,
    day: jd,
    year: jy,
    fullString
  };
}

export function getCurrentPersianTimeString(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function formatPersianDateString(dateStr: string): string {
  if (!dateStr) return '';
  return toPersianDigits(dateStr);
}

/**
 * Calculations for High School Grades in Iran
 */
export function calculateTerm1Score(record?: TermGradeRecord): number | null {
  if (!record) return null;
  const { continuousTerm1, finalTerm1 } = record;
  if (continuousTerm1 === null && finalTerm1 === null) return null;
  if (continuousTerm1 !== null && finalTerm1 !== null) {
    // Official Iranian formula for Term 1 result: (مستمر + پایانی×۲) / ۳ or (مستمر + پایانی) / ۲
    // Most high schools calculate (مستمر + پایانی × 2) / 3
    return Number(((continuousTerm1 + (finalTerm1 * 2)) / 3).toFixed(2));
  }
  return continuousTerm1 ?? finalTerm1;
}

export function calculateTerm2Score(record?: TermGradeRecord): number | null {
  if (!record) return null;
  const { continuousTerm2, finalTerm2 } = record;
  if (continuousTerm2 === null && finalTerm2 === null) return null;
  if (continuousTerm2 !== null && finalTerm2 !== null) {
    return Number(((continuousTerm2 + (finalTerm2 * 2)) / 3).toFixed(2));
  }
  return continuousTerm2 ?? finalTerm2;
}

export function calculateAnnualScore(record?: TermGradeRecord, config?: GradingFormulaConfig): number | null {
  if (!record) return null;
  const c1 = record.continuousTerm1;
  const f1 = record.finalTerm1;
  const c2 = record.continuousTerm2;
  const f2 = record.finalTerm2;

  // If none entered
  if (c1 === null && f1 === null && c2 === null && f2 === null) return null;

  const w_c1 = config?.continuousTerm1Weight ?? 1;
  const w_f1 = config?.finalTerm1Weight ?? 2;
  const w_c2 = config?.continuousTerm2Weight ?? 1;
  const w_f2 = config?.finalTerm2Weight ?? 4;

  let totalWeighted = 0;
  let totalWeight = 0;

  if (c1 !== null) { totalWeighted += c1 * w_c1; totalWeight += w_c1; }
  if (f1 !== null) { totalWeighted += f1 * w_f1; totalWeight += w_f1; }
  if (c2 !== null) { totalWeighted += c2 * w_c2; totalWeight += w_c2; }
  if (f2 !== null) { totalWeighted += f2 * w_f2; totalWeight += w_f2; }

  if (totalWeight === 0) return null;
  return Number((totalWeighted / totalWeight).toFixed(2));
}

export function getScoreBadge(score: number | null): {
  label: string;
  colorClass: string;
  bgClass: string;
  isPassing: boolean;
} {
  if (score === null) {
    return { label: 'ثبت نشده', colorClass: 'text-slate-400', bgClass: 'bg-slate-100 dark:bg-slate-800', isPassing: false };
  }
  if (score >= 18) {
    return { label: 'خیلی خوب (عالی)', colorClass: 'text-emerald-700 dark:text-emerald-300', bgClass: 'bg-emerald-50 dark:bg-emerald-950/40', isPassing: true };
  }
  if (score >= 15) {
    return { label: 'خوب', colorClass: 'text-sky-700 dark:text-sky-300', bgClass: 'bg-sky-50 dark:bg-sky-950/40', isPassing: true };
  }
  if (score >= 10) {
    return { label: 'قابل قبول', colorClass: 'text-amber-700 dark:text-amber-300', bgClass: 'bg-amber-50 dark:bg-amber-950/40', isPassing: true };
  }
  return { label: 'نیازمند تلاش (تجدید)', colorClass: 'text-rose-700 dark:text-rose-300', bgClass: 'bg-rose-50 dark:bg-rose-950/40', isPassing: false };
}

export function formatScore(score: number | null | undefined): string {
  if (score === null || score === undefined) return '-';
  // convert decimal dot to slash or decimal in Persian
  const formatted = score % 1 === 0 ? String(score) : score.toFixed(2).replace(/\.?0+$/, '');
  return toPersianDigits(formatted.replace('.', '/'));
}

/**
 * Export array of data to CSV with UTF-8 BOM for Microsoft Excel compatibility
 */
export function downloadCSV(filename: string, headers: string[], rows: (string | number)[][]): void {
  const bom = '\uFEFF';
  const csvContent = [
    headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(','),
    ...rows.map(row => row.map(val => `"${String(val ?? '').replace(/"/g, '""')}"`).join(','))
  ].join('\r\n');

  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
