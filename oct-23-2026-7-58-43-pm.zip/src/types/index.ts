export type GradeTerm = 'term1' | 'term2';

export interface Student {
  id: string;
  classId: string;
  nationalCode: string; // کد دانش‌آموزی یا کد ملی
  firstName: string;
  lastName: string;
  phone?: string;
  notes?: string;
  createdAt: string;
}

export interface GradingFormulaConfig {
  type: 'standard_iranian' | 'custom';
  // Standard Iranian high school weights:
  // Continuous 1: 1, Final 1: 2, Continuous 2: 1, Final 2: 4 (Total 8)
  continuousTerm1Weight: number;
  finalTerm1Weight: number;
  continuousTerm2Weight: number;
  finalTerm2Weight: number;
  passingThreshold: number; // usually 10
}

export interface ClassRoom {
  id: string;
  name: string; // مثلاً "کلاس ۱۰۱ تجربی"
  schoolName: string; // مثلاً "دبیرستان شهید بهشتی"
  grade: string; // پایه مثلاً "دهم", "یازدهم", "دوازدهم"
  field: string; // رشته مثلاً "علوم تجربی", "ریاضی و فیزیک", "علوم انسانی", "فنی و حرفه‌ای"
  academicYear: string; // مثلاً "۱۴۰۳-۱۴۰۴"
  subject: string; // مثلاً "زیست‌شناسی ۱"
  color?: string;
  gradingConfig: GradingFormulaConfig;
  createdAt: string;
}

export interface TermGradeRecord {
  id: string;
  studentId: string;
  classId: string;
  continuousTerm1: number | null; // مستمر نوبت اول
  finalTerm1: number | null;      // پایانی نوبت اول
  continuousTerm2: number | null; // مستمر نوبت دوم
  finalTerm2: number | null;      // پایانی نوبت دوم
  positiveScores: number;        // مثبت‌ها
  negativeScores: number;        // منفی‌ها
  updatedAt: string;
}

export interface CustomScore {
  id: string;
  studentId: string;
  classId: string;
  title: string;       // مثلاً "کوییز فصل اول", "پرسش شفاهی", "تکلیف عید"
  score: number;       // نمره کسب شده
  maxScore: number;    // نمره کل مثلاً 20 یا 5
  term: GradeTerm;
  date: string;        // تاریخ شمسی مثلاً "۱۴۰۳/۰۸/۱۵"
  description?: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface AttendanceRecord {
  studentId: string;
  status: AttendanceStatus;
  note?: string;
}

export interface AttendanceSession {
  id: string;
  classId: string;
  date: string;        // تاریخ شمسی مثلاً "۱۴۰۳/۰۸/۲۳"
  time: string;        // ساعت مثلاً "۰۸:۳۰"
  topic?: string;      // موضوع تدریس / درس
  records: Record<string, AttendanceStatus>; // studentId -> status
  notes?: string;
  createdAt: string;
}

export type NoteCategory = 'personal' | 'class' | 'student' | 'curriculum' | 'school';

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  date: string;
  category: NoteCategory;
  classId?: string;
  studentId?: string;
  updatedAt: string;
}

export type ReminderCategory = 'exam' | 'grades' | 'parents' | 'homework' | 'attendance' | 'other';
export type RecurrenceType = 'none' | 'weekly' | 'monthly';

export interface ReminderItem {
  id: string;
  title: string;
  description?: string;
  date: string; // شمسی e.g. "۱۴۰۳/۰۸/۳۰"
  time: string; // e.g. "۱۰:۰۰"
  category: ReminderCategory;
  recurrence: RecurrenceType;
  completed: boolean;
  classId?: string;
  createdAt: string;
}

export type ActiveTab = 'dashboard' | 'classes' | 'gradebook' | 'attendance' | 'more';
export type MoreSubTab = 'reports' | 'notes' | 'reminders' | 'backup';
