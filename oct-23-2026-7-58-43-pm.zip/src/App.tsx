import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/DashboardView';
import { ClassesView } from './components/ClassesView';
import { GradebookView } from './components/GradebookView';
import { AttendanceView } from './components/AttendanceView';
import { MoreView } from './components/MoreView';
import { StudentProfileModal } from './components/StudentProfileModal';
import { SettingsBackupModal } from './components/SettingsBackupModal';
import { AddStudentModal } from './components/AddStudentModal';
import { AddReminderModal } from './components/AddReminderModal';
import { AddNoteModal } from './components/AddNoteModal';
import { InstallAppModal } from './components/InstallAppModal';
import { ToastContainer } from './components/ToastContainer';

const MainLayout: React.FC = () => {
  const { activeTab, setActiveTab, selectedStudentProfileId, setSelectedStudentProfileId } = useApp();

  const [showSettings, setShowSettings] = useState(false);
  const [showInstall, setShowInstall] = useState(false);
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [showAddReminder, setShowAddReminder] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [initialOpenNewAttendance, setInitialOpenNewAttendance] = useState(false);

  const handleOpenNewAttendance = () => {
    setInitialOpenNewAttendance(true);
    setActiveTab('attendance');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors antialiased">
      {/* Top Application Bar */}
      <Header
        onOpenSettings={() => setShowSettings(true)}
        onOpenInstall={() => setShowInstall(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 sm:px-4 pt-4 md:pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            onOpenAddStudent={() => setShowAddStudent(true)}
            onOpenAddReminder={() => setShowAddReminder(true)}
            onOpenAddNote={() => setShowAddNote(true)}
            onOpenNewSession={handleOpenNewAttendance}
            onOpenInstall={() => setShowInstall(true)}
          />
        )}

        {activeTab === 'classes' && (
          <ClassesView onOpenAddStudent={() => setShowAddStudent(true)} />
        )}

        {activeTab === 'gradebook' && <GradebookView />}

        {activeTab === 'attendance' && (
          <AttendanceView initialOpenNewSession={initialOpenNewAttendance} />
        )}

        {activeTab === 'more' && (
          <MoreView
            onOpenSettings={() => setShowSettings(true)}
            onOpenInstall={() => setShowInstall(true)}
          />
        )}
      </main>

      {/* Fixed Ergonomic Bottom Thumb Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(t) => {
          setInitialOpenNewAttendance(false);
          setActiveTab(t);
        }}
      />

      {/* Toast Feedbacks */}
      <ToastContainer />

      {/* Student Dossier Modal */}
      {selectedStudentProfileId && (
        <StudentProfileModal
          studentId={selectedStudentProfileId}
          onClose={() => setSelectedStudentProfileId(null)}
        />
      )}

      {/* Settings & Backup Modal */}
      {showSettings && <SettingsBackupModal onClose={() => setShowSettings(false)} />}

      {/* Install App Modal */}
      {showInstall && <InstallAppModal onClose={() => setShowInstall(false)} />}

      {/* Quick Add Modals */}
      {showAddStudent && <AddStudentModal onClose={() => setShowAddStudent(false)} />}
      {showAddReminder && <AddReminderModal onClose={() => setShowAddReminder(false)} />}
      {showAddNote && <AddNoteModal onClose={() => setShowAddNote(false)} />}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
