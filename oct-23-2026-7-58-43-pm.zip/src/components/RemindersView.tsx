import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bell, Plus, Check, Clock, Calendar, Trash2, Edit2, X, AlertCircle } from 'lucide-react';
import { getCurrentPersianTimeString, getTodayJalaliString, toPersianDigits } from '../utils/persian';
import { RecurrenceType, ReminderCategory, ReminderItem } from '../types';

export const RemindersView: React.FC = () => {
  const { reminders, activeClass, addReminder, updateReminder, toggleReminderComplete, deleteReminder, showToast } = useApp();
  const [filterType, setFilterType] = useState<'active' | 'completed' | 'all'>('active');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingRem, setEditingRem] = useState<ReminderItem | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(getTodayJalaliString());
  const [time, setTime] = useState(getCurrentPersianTimeString());
  const [category, setCategory] = useState<ReminderCategory>('exam');
  const [recurrence, setRecurrence] = useState<RecurrenceType>('none');

  const categoriesMap: Record<ReminderCategory, { label: string; color: string }> = {
    exam: { label: 'برگزاری آزمون', color: 'text-rose-600 bg-rose-50 dark:bg-rose-950/40' },
    grades: { label: 'ثبت نمرات در سیدا', color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40' },
    parents: { label: 'جلسه با اولیا', color: 'text-sky-600 bg-sky-50 dark:bg-sky-950/40' },
    homework: { label: 'تحویل و بررسی تکلیف', color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/40' },
    attendance: { label: 'بازبینی حضور و غیاب', color: 'text-teal-600 bg-teal-50 dark:bg-teal-950/40' },
    other: { label: 'سایر امور', color: 'text-slate-600 bg-slate-50 dark:bg-slate-800' },
  };

  const handleOpenAdd = () => {
    setEditingRem(null);
    setTitle('');
    setDescription('');
    setDate(getTodayJalaliString());
    setTime('۱۰:۰۰');
    setCategory('exam');
    setRecurrence('none');
    setShowAddModal(true);
  };

  const handleOpenEdit = (r: ReminderItem) => {
    setEditingRem(r);
    setTitle(r.title);
    setDescription(r.description || '');
    setDate(r.date);
    setTime(r.time);
    setCategory(r.category);
    setRecurrence(r.recurrence);
    setShowAddModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('عنوان یادآوری را وارد نمایید', 'error');
      return;
    }

    if (editingRem) {
      updateReminder(editingRem.id, {
        title: title.trim(),
        description: description.trim(),
        date,
        time,
        category,
        recurrence,
      });
    } else {
      addReminder({
        title: title.trim(),
        description: description.trim(),
        date,
        time,
        category,
        recurrence,
        completed: false,
        classId: activeClass?.id,
      });
    }

    setShowAddModal(false);
  };

  const requestNotificationPermission = () => {
    if ('Notification' in window) {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
          showToast('اعلان‌های مرورگر با موفقیت فعال شدند');
          new Notification('دفتر نمره', {
            body: 'سیستم اعلان یادآوری‌های کلاسی فعال گردید.',
          });
        } else {
          showToast('دسترسی اعلان توسط مرورگر مجاز نشد', 'info');
        }
      });
    } else {
      showToast('مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند', 'info');
    }
  };

  const filteredReminders = reminders.filter((r) => {
    if (filterType === 'active') return !r.completed;
    if (filterType === 'completed') return r.completed;
    return true;
  });

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div>
          <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-500" />
            <span>یادآوری‌ها و تقویم وظایف</span>
          </h1>
          <p className="text-xs text-slate-500">
            برنامه‌ریزی امتحانات، زمان‌بندی ثبت نمرات در سامانه سیدا و جلسات اولیا
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={requestNotificationPermission}
            className="px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl transition-colors"
          >
            فعال‌سازی اعلان
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>یادآوری جدید</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
        <button
          onClick={() => setFilterType('active')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            filterType === 'active'
              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          در انتظار انجام ({toPersianDigits(reminders.filter((r) => !r.completed).length)})
        </button>
        <button
          onClick={() => setFilterType('completed')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            filterType === 'completed'
              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          انجام شده ({toPersianDigits(reminders.filter((r) => r.completed).length)})
        </button>
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            filterType === 'all'
              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          همه
        </button>
      </div>

      {/* Reminders List */}
      {filteredReminders.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
          هیچ موردی در این بخش وجود ندارد.
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredReminders.map((rem) => {
            const catInfo = categoriesMap[rem.category] || categoriesMap.other;

            return (
              <div
                key={rem.id}
                className={`p-4 bg-white dark:bg-slate-900 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                  rem.completed
                    ? 'border-slate-200 dark:border-slate-800 opacity-60'
                    : 'border-slate-200 dark:border-slate-800 shadow-2xs hover:border-amber-400'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <button
                    onClick={() => toggleReminderComplete(rem.id)}
                    className={`mt-0.5 w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 transition-colors ${
                      rem.completed
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 dark:border-slate-700 hover:border-emerald-500'
                    }`}
                  >
                    {rem.completed && <Check className="w-4 h-4" />}
                  </button>

                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-xs md:text-sm font-bold block ${
                          rem.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {rem.title}
                      </span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${catInfo.color}`}>
                        {catInfo.label}
                      </span>
                      {rem.recurrence !== 'none' && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500">
                          {rem.recurrence === 'weekly' ? 'تکرار هفتگی' : 'تکرار ماهانه'}
                        </span>
                      )}
                    </div>

                    {rem.description && (
                      <p className="text-xs text-slate-500 leading-relaxed">
                        {rem.description}
                      </p>
                    )}

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{toPersianDigits(rem.date)}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>ساعت {toPersianDigits(rem.time)}</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenEdit(rem)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    title="ویرایش"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteReminder(rem.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                    title="حذف"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white">
                {editingRem ? 'ویرایش یادآوری' : 'یادآوری جدید'}
              </h2>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">موضوع یادآوری</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثلاً: آزمون میان‌ترم زیست یا ثبت نمرات سیدا..."
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">نوع یادآوری</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ReminderCategory)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  >
                    <option value="exam">برگزاری آزمون</option>
                    <option value="grades">ثبت نمرات در سیدا</option>
                    <option value="parents">جلسه با اولیا</option>
                    <option value="homework">تحویل و بررسی تکلیف</option>
                    <option value="attendance">بازبینی حضور و غیاب</option>
                    <option value="other">سایر امور</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">تناوب تکرار</label>
                  <select
                    value={recurrence}
                    onChange={(e) => setRecurrence(e.target.value as RecurrenceType)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  >
                    <option value="none">فقط یک‌بار</option>
                    <option value="weekly">هر هفته (هفتگی)</option>
                    <option value="monthly">هر ماه (ماهانه)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">تاریخ (شمسی)</label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">ساعت</label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 mb-1">توضیحات تکمیلی (اختیاری)</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="مباحث امتحان، اسامی دانش‌آموزان مورد نظر یا شماره تماس..."
                  rows={2}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-medium bg-amber-600 text-white rounded-xl hover:bg-amber-700"
                >
                  {editingRem ? 'ذخیره تغییرات' : 'افزودن یادآوری'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
