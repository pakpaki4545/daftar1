import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Download,
  Plus,
  Minus,
  Settings,
  Search,
  Filter,
  CheckCircle2,
  Trash2,
  Calendar,
  X,
  FileSpreadsheet,
  Award,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  calculateAnnualScore,
  calculateTerm1Score,
  calculateTerm2Score,
  formatScore,
  getScoreBadge,
  toEnglishDigits,
  toPersianDigits,
} from '../utils/persian';
import { CustomScore, GradingFormulaConfig } from '../types';

export const GradebookView: React.FC = () => {
  const {
    students,
    grades,
    customScores,
    activeClass,
    updateTermGrade,
    adjustPositiveScore,
    adjustNegativeScore,
    addCustomScore,
    deleteCustomScore,
    updateGradingFormula,
    setSelectedStudentProfileId,
    exportClassGradesToCSV,
    showToast,
  } = useApp();

  const [activeView, setActiveView] = useState<'all' | 'term1' | 'term2' | 'custom'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFormulaModal, setShowFormulaModal] = useState(false);
  const [showAddCustomModal, setShowAddCustomModal] = useState(false);

  // New Custom Score Form State
  const [customTitle, setCustomTitle] = useState('');
  const [customScoreVal, setCustomScoreVal] = useState('۲۰');
  const [customMaxScoreVal, setCustomMaxScoreVal] = useState('۲۰');
  const [customTerm, setCustomTerm] = useState<'term1' | 'term2'>('term1');
  const [customDate, setCustomDate] = useState('۱۴۰۳/۰۸/۲۵');
  const [customDesc, setCustomDesc] = useState('');
  const [customStudentId, setCustomStudentId] = useState('');

  // Formula Form State
  const [configC1, setConfigC1] = useState(String(activeClass?.gradingConfig?.continuousTerm1Weight ?? 1));
  const [configF1, setConfigF1] = useState(String(activeClass?.gradingConfig?.finalTerm1Weight ?? 2));
  const [configC2, setConfigC2] = useState(String(activeClass?.gradingConfig?.continuousTerm2Weight ?? 1));
  const [configF2, setConfigF2] = useState(String(activeClass?.gradingConfig?.finalTerm2Weight ?? 4));
  const [configThreshold, setConfigThreshold] = useState(String(activeClass?.gradingConfig?.passingThreshold ?? 10));

  if (!activeClass) {
    return (
      <div className="p-8 text-center text-slate-500">
        لطفاً ابتدا یک کلاس ایجاد یا انتخاب نمایید.
      </div>
    );
  }

  const classStudents = students.filter((s) => s.classId === activeClass.id);
  const filteredStudents = classStudents.filter((s) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    const fullName = `${s.firstName} ${s.lastName}`.toLowerCase();
    const code = s.nationalCode.toLowerCase();
    return fullName.includes(q) || code.includes(q);
  });

  const handleScoreInputBlur = (
    studentId: string,
    field: 'continuousTerm1' | 'finalTerm1' | 'continuousTerm2' | 'finalTerm2',
    valStr: string
  ) => {
    if (!valStr || valStr.trim() === '' || valStr.trim() === '-') {
      updateTermGrade(studentId, activeClass.id, field, null);
      return;
    }
    const cleanNum = Number(toEnglishDigits(valStr.trim()));
    if (isNaN(cleanNum)) {
      showToast('لطفاً نمره معتبر عددی وارد نمایید', 'error');
      return;
    }
    if (cleanNum < 0 || cleanNum > 20) {
      showToast('نمره باید بین ۰ تا ۲۰ باشد', 'error');
      return;
    }
    // Round to nearest quarter (0.25)
    const rounded = Math.round(cleanNum * 4) / 4;
    updateTermGrade(studentId, activeClass.id, field, rounded);
  };

  const handleSaveFormula = (e: React.FormEvent) => {
    e.preventDefault();
    const newConfig: GradingFormulaConfig = {
      type: 'custom',
      continuousTerm1Weight: Number(toEnglishDigits(configC1)) || 1,
      finalTerm1Weight: Number(toEnglishDigits(configF1)) || 2,
      continuousTerm2Weight: Number(toEnglishDigits(configC2)) || 1,
      finalTerm2Weight: Number(toEnglishDigits(configF2)) || 4,
      passingThreshold: Number(toEnglishDigits(configThreshold)) || 10,
    };
    updateGradingFormula(activeClass.id, newConfig);
    setShowFormulaModal(false);
  };

  const handleSaveCustomScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) {
      showToast('عنوان فعالیت را وارد نمایید', 'error');
      return;
    }
    const scoreNum = Number(toEnglishDigits(customScoreVal));
    const maxScoreNum = Number(toEnglishDigits(customMaxScoreVal));

    if (isNaN(scoreNum) || scoreNum < 0) {
      showToast('نمره معتبر نیست', 'error');
      return;
    }

    if (customStudentId === 'ALL') {
      // Add for all students in class
      classStudents.forEach((st) => {
        addCustomScore({
          studentId: st.id,
          classId: activeClass.id,
          title: customTitle.trim(),
          score: scoreNum,
          maxScore: maxScoreNum || 20,
          term: customTerm,
          date: customDate.trim(),
          description: customDesc.trim(),
        });
      });
      showToast(`نمره فعالیت برای همه دانش‌آموزان ثبت شد`);
    } else {
      addCustomScore({
        studentId: customStudentId || classStudents[0]?.id,
        classId: activeClass.id,
        title: customTitle.trim(),
        score: scoreNum,
        maxScore: maxScoreNum || 20,
        term: customTerm,
        date: customDate.trim(),
        description: customDesc.trim(),
      });
    }

    setShowAddCustomModal(false);
    setCustomTitle('');
    setCustomDesc('');
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Top Header & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div>
          <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
            <span>دفتر نمرات کلاسی: {activeClass.name}</span>
          </h1>
          <p className="text-xs text-slate-500">
            ورود سریع نمرات با اعشار (۰/۲۵ و ۰/۵)، مثبت و منفی و محاسبه خودکار نوبت اول، دوم و سالانه
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowAddCustomModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 rounded-xl border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>ثبت کوییز و فعالیت</span>
          </button>

          <button
            onClick={() => setShowFormulaModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>تنظیم فرمول نمرات</span>
          </button>

          <button
            onClick={() => exportClassGradesToCSV(activeClass.id)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>خروجی اکسل</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Segmented View Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-full sm:w-auto overflow-x-auto">
          <button
            onClick={() => setActiveView('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 ${
              activeView === 'all'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            همه نمرات و سالانه
          </button>
          <button
            onClick={() => setActiveView('term1')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 ${
              activeView === 'term1'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            نوبت اول (دی‌ماه)
          </button>
          <button
            onClick={() => setActiveView('term2')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 ${
              activeView === 'term2'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            نوبت دوم (خرداد‌ماه)
          </button>
          <button
            onClick={() => setActiveView('custom')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 ${
              activeView === 'custom'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            کوییز و فعالیت‌ها ({toPersianDigits(customScores.filter((c) => c.classId === activeClass.id).length)})
          </button>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجوی نام یا کد دانش‌آموز..."
            className="w-full text-xs py-2 ps-8 pe-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      {/* Main Gradebook Spreadsheet View */}
      {activeView !== 'custom' ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          {filteredStudents.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              {searchQuery ? 'دانش‌آموزی با این مشخصات یافت نشد.' : 'هنوز دانش‌آموزی در این کلاس ثبت نشده است.'}
            </div>
          ) : (
            <div className="overflow-x-auto relative">
              <table className="w-full text-right text-xs border-collapse">
                <thead className="bg-slate-100 dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    {/* Sticky right student info column */}
                    <th className="py-3 px-3 sticky right-0 bg-slate-100 dark:bg-slate-800 z-20 min-w-[150px] shadow-sm">
                      نام و نام خانوادگی
                    </th>
                    <th className="py-3 px-2 text-center min-w-[90px]">
                      فعالیت (+ / -)
                    </th>

                    {/* Term 1 Columns */}
                    {(activeView === 'all' || activeView === 'term1') && (
                      <>
                        <th className="py-3 px-2 text-center min-w-[75px] bg-emerald-50/40 dark:bg-emerald-950/20">
                          مستمر ۱
                        </th>
                        <th className="py-3 px-2 text-center min-w-[75px] bg-emerald-50/40 dark:bg-emerald-950/20">
                          پایانی ۱
                        </th>
                        <th className="py-3 px-2 text-center min-w-[80px] bg-emerald-100/40 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300">
                          نمره ترم ۱
                        </th>
                      </>
                    )}

                    {/* Term 2 Columns */}
                    {(activeView === 'all' || activeView === 'term2') && (
                      <>
                        <th className="py-3 px-2 text-center min-w-[75px] bg-sky-50/40 dark:bg-sky-950/20">
                          مستمر ۲
                        </th>
                        <th className="py-3 px-2 text-center min-w-[75px] bg-sky-50/40 dark:bg-sky-950/20">
                          پایانی ۲
                        </th>
                        <th className="py-3 px-2 text-center min-w-[80px] bg-sky-100/40 dark:bg-sky-900/30 text-sky-800 dark:text-sky-300">
                          نمره ترم ۲
                        </th>
                      </>
                    )}

                    {/* Annual Column */}
                    {activeView === 'all' && (
                      <th className="py-3 px-2 text-center min-w-[90px] bg-slate-200/60 dark:bg-slate-700/60 font-bold">
                        نمره سالانه
                      </th>
                    )}

                    <th className="py-3 px-2 text-center min-w-[90px]">
                      وضعیت
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {filteredStudents.map((student, idx) => {
                    const grade = grades.find(
                      (g) => g.studentId === student.id && g.classId === activeClass.id
                    );
                    const t1 = calculateTerm1Score(grade);
                    const t2 = calculateTerm2Score(grade);
                    const annual = calculateAnnualScore(grade, activeClass.gradingConfig);
                    const badge = getScoreBadge(annual);

                    return (
                      <tr
                        key={student.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group"
                      >
                        {/* Sticky Name Cell */}
                        <td className="py-2 px-3 sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50/80 dark:group-hover:bg-slate-800/40 z-10 shadow-sm border-s-2 border-transparent hover:border-emerald-500">
                          <button
                            onClick={() => setSelectedStudentProfileId(student.id)}
                            className="text-right flex flex-col hover:text-emerald-600 transition-colors truncate max-w-[140px]"
                          >
                            <span className="font-bold text-slate-800 dark:text-slate-100 truncate">
                              {student.firstName} {student.lastName}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {toPersianDigits(student.nationalCode) || `ردیف ${toPersianDigits(idx + 1)}`}
                            </span>
                          </button>
                        </td>

                        {/* Positive & Negative Quick Buttons */}
                        <td className="py-2 px-2 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Positive button */}
                            <div className="flex items-center bg-emerald-50 dark:bg-emerald-950/40 rounded-lg p-0.5 border border-emerald-200/50 dark:border-emerald-800/50">
                              <button
                                onClick={() => adjustPositiveScore(student.id, activeClass.id, 1)}
                                title="افزودن مثبت"
                                className="w-5 h-5 rounded bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center text-xs font-bold"
                              >
                                +
                              </button>
                              <span className="px-1.5 font-bold text-emerald-700 dark:text-emerald-300 text-xs tabular-nums">
                                {toPersianDigits(grade?.positiveScores || 0)}
                              </span>
                              <button
                                onClick={() => adjustPositiveScore(student.id, activeClass.id, -1)}
                                title="کاهش مثبت"
                                className="w-5 h-5 rounded hover:bg-emerald-200 dark:hover:bg-emerald-800 text-emerald-800 dark:text-emerald-200 flex items-center justify-center text-xs"
                              >
                                -
                              </button>
                            </div>

                            {/* Negative button */}
                            <div className="flex items-center bg-rose-50 dark:bg-rose-950/40 rounded-lg p-0.5 border border-rose-200/50 dark:border-rose-800/50">
                              <button
                                onClick={() => adjustNegativeScore(student.id, activeClass.id, 1)}
                                title="افزودن منفی"
                                className="w-5 h-5 rounded bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center text-xs font-bold"
                              >
                                -
                              </button>
                              <span className="px-1.5 font-bold text-rose-700 dark:text-rose-300 text-xs tabular-nums">
                                {toPersianDigits(grade?.negativeScores || 0)}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Continuous 1 Input */}
                        {(activeView === 'all' || activeView === 'term1') && (
                          <>
                            <td className="py-2 px-1 text-center bg-emerald-50/20 dark:bg-emerald-950/10">
                              <input
                                type="text"
                                defaultValue={grade?.continuousTerm1 !== null && grade?.continuousTerm1 !== undefined ? String(grade.continuousTerm1) : ''}
                                key={`c1-${student.id}-${grade?.continuousTerm1}`}
                                onBlur={(e) => handleScoreInputBlur(student.id, 'continuousTerm1', e.target.value)}
                                placeholder="-"
                                className="w-14 text-center font-bold text-xs py-1 px-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none tabular-nums"
                              />
                            </td>
                            <td className="py-2 px-1 text-center bg-emerald-50/20 dark:bg-emerald-950/10">
                              <input
                                type="text"
                                defaultValue={grade?.finalTerm1 !== null && grade?.finalTerm1 !== undefined ? String(grade.finalTerm1) : ''}
                                key={`f1-${student.id}-${grade?.finalTerm1}`}
                                onBlur={(e) => handleScoreInputBlur(student.id, 'finalTerm1', e.target.value)}
                                placeholder="-"
                                className="w-14 text-center font-bold text-xs py-1 px-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none tabular-nums"
                              />
                            </td>
                            <td className="py-2 px-2 text-center font-black text-emerald-700 dark:text-emerald-300 bg-emerald-100/20 dark:bg-emerald-900/10 tabular-nums">
                              {formatScore(t1)}
                            </td>
                          </>
                        )}

                        {/* Term 2 Columns */}
                        {(activeView === 'all' || activeView === 'term2') && (
                          <>
                            <td className="py-2 px-1 text-center bg-sky-50/20 dark:bg-sky-950/10">
                              <input
                                type="text"
                                defaultValue={grade?.continuousTerm2 !== null && grade?.continuousTerm2 !== undefined ? String(grade.continuousTerm2) : ''}
                                key={`c2-${student.id}-${grade?.continuousTerm2}`}
                                onBlur={(e) => handleScoreInputBlur(student.id, 'continuousTerm2', e.target.value)}
                                placeholder="-"
                                className="w-14 text-center font-bold text-xs py-1 px-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none tabular-nums"
                              />
                            </td>
                            <td className="py-2 px-1 text-center bg-sky-50/20 dark:bg-sky-950/10">
                              <input
                                type="text"
                                defaultValue={grade?.finalTerm2 !== null && grade?.finalTerm2 !== undefined ? String(grade.finalTerm2) : ''}
                                key={`f2-${student.id}-${grade?.finalTerm2}`}
                                onBlur={(e) => handleScoreInputBlur(student.id, 'finalTerm2', e.target.value)}
                                placeholder="-"
                                className="w-14 text-center font-bold text-xs py-1 px-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none tabular-nums"
                              />
                            </td>
                            <td className="py-2 px-2 text-center font-black text-sky-700 dark:text-sky-300 bg-sky-100/20 dark:bg-sky-900/10 tabular-nums">
                              {formatScore(t2)}
                            </td>
                          </>
                        )}

                        {/* Annual Score Column */}
                        {activeView === 'all' && (
                          <td className="py-2 px-2 text-center font-black text-sm bg-slate-100/60 dark:bg-slate-800/40 tabular-nums">
                            <span className={badge.colorClass}>
                              {formatScore(annual)}
                            </span>
                          </td>
                        )}

                        {/* Status Label */}
                        <td className="py-2 px-2 text-center">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badge.bgClass} ${badge.colorClass}`}>
                            {badge.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* Custom Scores Sub-View */
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              لیست کوییزها، پرسش‌های شفاهی و تکالیف کلاسی
            </h2>
            <button
              onClick={() => setShowAddCustomModal(true)}
              className="flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>افزودن مورد جدید</span>
            </button>
          </div>

          {customScores.filter((c) => c.classId === activeClass.id).length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              هنوز آزمون یا کوییز ثبت نشده است. با دکمه بالا اولین فعالیت را ثبت نمایید.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {customScores
                .filter((c) => c.classId === activeClass.id)
                .map((cs) => {
                  const student = students.find((s) => s.id === cs.studentId);
                  return (
                    <div
                      key={cs.id}
                      className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                            {cs.title}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                            {cs.term === 'term1' ? 'نوبت اول' : 'نوبت دوم'}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 block mt-0.5">
                          {student ? `${student.firstName} ${student.lastName}` : 'عمومی'} · {toPersianDigits(cs.date)}
                        </span>
                        {cs.description && (
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            {cs.description}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2.5">
                        <span className="text-sm font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                          {toPersianDigits(cs.score)} / {toPersianDigits(cs.maxScore)}
                        </span>
                        <button
                          onClick={() => deleteCustomScore(cs.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="حذف این نمره"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* Modal: Add Custom Score */}
      {showAddCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white">
                ثبت کوییز یا نمره فعالیت کلاسی
              </h2>
              <button onClick={() => setShowAddCustomModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomScore} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">دانش‌آموز</label>
                <select
                  value={customStudentId}
                  onChange={(e) => setCustomStudentId(e.target.value)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                >
                  <option value="ALL">همه دانش‌آموزان کلاس (ثبت گروهی با نمره پیش‌فرض)</option>
                  {classStudents.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.firstName} {st.lastName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-500 mb-1">عنوان آزمون / فعالیت</label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="مثلاً: کوییز فصل دوم، پرسش شفاهی، کارعملی..."
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">نمره کسب شده</label>
                  <input
                    type="text"
                    value={customScoreVal}
                    onChange={(e) => setCustomScoreVal(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">از کل نمره (بارم)</label>
                  <input
                    type="text"
                    value={customMaxScoreVal}
                    onChange={(e) => setCustomMaxScoreVal(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">نوبت تحصیلی</label>
                  <select
                    value={customTerm}
                    onChange={(e) => setCustomTerm(e.target.value as 'term1' | 'term2')}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  >
                    <option value="term1">نوبت اول</option>
                    <option value="term2">نوبت دوم</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">تاریخ (شمسی)</label>
                  <input
                    type="text"
                    value={customDate}
                    onChange={(e) => setCustomDate(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 mb-1">توضیحات اختیاری</label>
                <textarea
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  placeholder="مباحث، سوالات یا بازخورد معلم..."
                  rows={2}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddCustomModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-medium bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
                >
                  ثبت نمره
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Formula Settings */}
      {showFormulaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-emerald-600" />
                <span>تنظیم ضرایب و فرمول نمرات کلاسی</span>
              </h2>
              <button onClick={() => setShowFormulaModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-start gap-2">
              <Info className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                فرمول استاندارد دبیرستان‌های ایران:
                <br />
                نمره سالانه = (پایانی۲ × ۴ + مستمر۲ × ۱ + پایانی۱ × ۲ + مستمر۱ × ۱) ÷ ۸
              </span>
            </div>

            <form onSubmit={handleSaveFormula} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">ضریب مستمر نوبت اول</label>
                  <input
                    type="number"
                    step="0.5"
                    value={configC1}
                    onChange={(e) => setConfigC1(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">ضریب پایانی نوبت اول</label>
                  <input
                    type="number"
                    step="0.5"
                    value={configF1}
                    onChange={(e) => setConfigF1(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">ضریب مستمر نوبت دوم</label>
                  <input
                    type="number"
                    step="0.5"
                    value={configC2}
                    onChange={(e) => setConfigC2(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">ضریب پایانی نوبت دوم</label>
                  <input
                    type="number"
                    step="0.5"
                    value={configF2}
                    onChange={(e) => setConfigF2(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 mb-1">حد نصاب قبولی (نمره کف)</label>
                <input
                  type="number"
                  step="0.5"
                  value={configThreshold}
                  onChange={(e) => setConfigThreshold(e.target.value)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowFormulaModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-medium bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
                >
                  ذخیره فرمول
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
