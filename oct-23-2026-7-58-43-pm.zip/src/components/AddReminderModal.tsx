import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Bell } from 'lucide-react';
import { getCurrentPersianTimeString, getTodayJalaliString } from '../utils/persian';
import { RecurrenceType, ReminderCategory } from '../types';

interface AddReminderModalProps {
  onClose: () => void;
}

export const AddReminderModal: React.FC<AddReminderModalProps> = ({ onClose }) => {
  const { activeClass, addReminder, showToast } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(getTodayJalaliString());
  const [time, setTime] = useState(getCurrentPersianTimeString());
  const [category, setCategory] = useState<ReminderCategory>('exam');
  const [recurrence, setRecurrence] = useState<RecurrenceType>('none');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('عنوان یادآوری را وارد نمایید', 'error');
      return;
    }

    addReminder({
      title: title.trim(),
      description: description.trim(),
      date,
      time,
      category,
      recurrence,
      completed: false,
      classId: activeClass?.id,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-500" />
            <span>ثبت یادآوری جدید</span>
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">موضوع یادآوری *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثلاً: آزمون میان‌ترم، ثبت نمرات در سیدا..."
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-500 mb-1">نوع یادآوری</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ReminderCategory)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
              >
                <option value="exam">برگزاری آزمون</option>
                <option value="grades">ثبت نمرات در سیدا</option>
                <option value="parents">جلسه با اولیا</option>
                <option value="homework">تحویل و بررسی تکلیف</option>
                <option value="attendance">بازبینی حضور و غیاب</option>
                <option value="other">سایر امور</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-500 mb-1">تناوب تکرار</label>
              <select
                value={recurrence}
                onChange={(e) => setRecurrence(e.target.value as RecurrenceType)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
              >
                <option value="none">فقط یک‌بار</option>
                <option value="weekly">هر هفته (هفتگی)</option>
                <option value="monthly">هر ماه (ماهانه)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-500 mb-1">تاریخ (شمسی)</label>
              <input
                type="text"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-500 mb-1">ساعت</label>
              <input
                type="text"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">توضیحات تکمیلی (اختیاری)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="نکات، منابع یا توضیحات..."
              rows={2}
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
            >
              انصراف
            </button>
            <button
              type="submit"
              className="px-5 py-2 font-medium bg-amber-600 text-white rounded-xl hover:bg-amber-700"
            >
              ثبت یادآوری
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
