import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  Smartphone,
  Download,
  Share2,
  PlusSquare,
  CheckCircle2,
  Copy,
  ExternalLink,
  X,
  Info,
  Sparkles,
  Apple,
  Globe,
} from 'lucide-react';

interface InstallAppModalProps {
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [activePlatform, setActivePlatform] = useState<'android' | 'ios'>(
    isIOS ? 'ios' : 'android'
  );
  const [copied, setCopied] = useState(false);

  // Current URL or origin
  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-him7nbmm3rehoqnqjdfcq2-541413767642.us-east1.run.app';

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                نصب برنامه «دفتر نمره» روی موبایل
              </h2>
              <p className="text-[11px] text-slate-500">
                وب‌اپلیکیشن پیشرو (PWA) بدون نیاز به بازار و گوگل‌پلی
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content (Scrollable) */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          {/* Quick Direct Install Trigger (if browser allows beforeinstallprompt) */}
          {isInstallable && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-0.5 text-center sm:text-right">
                <span className="font-bold text-xs text-emerald-900 dark:text-emerald-200 block">
                  نصب مستقیم با یک کلیک آماده است!
                </span>
                <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  برای افزودن خودکار آیکون برنامه به صفحه اصلی گوشی لمس کنید.
                </span>
              </div>
              <button
                onClick={handleNativeInstall}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-2 shadow-sm transition-all active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>نصب فوری روی گوشی</span>
              </button>
            </div>
          )}

          {/* Already installed banner */}
          {isInstalled && (
            <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex items-center gap-2.5 text-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
              <span>
                برنامه در حال حاضر روی دستگاه شما نصب شده و در حالت تمام‌صفحه اجرا می‌شود.
              </span>
            </div>
          )}

          {/* Platform Switcher Tabs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                راهنمای نصب بر اساس نوع گوشی شما:
              </span>
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  onClick={() => setActivePlatform('android')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    activePlatform === 'android'
                      ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  گوشی‌های اندروید
                </button>
                <button
                  onClick={() => setActivePlatform('ios')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    activePlatform === 'ios'
                      ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  آیفون و آیپد (iOS)
                </button>
              </div>
            </div>

            {/* Android Instructions */}
            {activePlatform === 'android' && (
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  <span>مراحل نصب در مرورگر Chrome یا سامسونگ اینترنت:</span>
                </h3>
                <div className="space-y-2.5 pt-1">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۱
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      در بالای صفحه مرورگر کروم، علامت <strong>سه نقطه (⋮)</strong> را لمس کنید.
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۲
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      گزینه <strong>«افزودن به صفحه اصلی» (Add to Home screen)</strong> یا <strong>«نصب برنامه» (Install app)</strong> را انتخاب نمایید.
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۳
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      دکمه <strong>«نصب» (Install)</strong> را تایید کنید. آیکون «دفتر نمره» مانند برنامه‌های اصلی روی گوشی شما قرار می‌گیرد.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* iOS Instructions */}
            {activePlatform === 'ios' && (
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Apple className="w-4 h-4 text-slate-900 dark:text-white" />
                  <span>مراحل نصب در مرورگر Safari آیفون:</span>
                </h3>
                <div className="space-y-2.5 pt-1">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۱
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      این صفحه را در مرورگر اصلی آیفون یعنی <strong>Safari</strong> باز کنید.
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۲
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      در نوار پایین صفحه، دکمه <strong>اشتراک‌گذاری (Share)</strong> را لمس کنید (آیکون مربع با فلش رو به بالا <Share2 className="w-3.5 h-3.5 inline mx-1 text-sky-500" />).
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۳
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      در لیست گزینه‌ها به پایین حرکت کرده و روی <strong>«Add to Home Screen» (افزودن به صفحه اصلی <PlusSquare className="w-3.5 h-3.5 inline mx-1" />)</strong> بزنید.
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ۴
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      در بالای صفحه سمت راست، دکمه <strong>«Add» (افزودن)</strong> را بزنید. کار تمام است!
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Share / Open on Phone Section */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5">
            <span className="font-bold text-slate-800 dark:text-slate-200 block">
              آدرس باز کردن در مرورگر موبایل:
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="w-full text-[11px] py-2 px-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-mono outline-none truncate"
                dir="ltr"
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 shrink-0 font-medium flex items-center gap-1.5 transition-colors"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'کپی شد' : 'کپی آدرس'}</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-400">
              می‌توانید این لینک را در پیام‌رسان (ایتا، شاد، تلگرام یا پیامک) به گوشی خود ارسال کنید و در مرورگر باز کنید.
            </p>
          </div>

          {/* Advantages of PWA for Teachers */}
          <div className="space-y-1.5 text-[11px] text-slate-500">
            <span className="font-bold text-slate-700 dark:text-slate-300 block">
              مزایای نصب دفتر نمره:
            </span>
            <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400">
              <li>کارکرد آفلاین حتی در صورت قطع بودن اینترنت مدرسه</li>
              <li>اجرای تمام‌صفحه مشابه نرم‌افزارهای بومی بدون کادرهای اضافی مرورگر</li>
              <li>دسترسی سریع و آنی از صفحه اصلی گوشی در حین حضور در کلاس درس</li>
              <li>ذخیره‌سازی کاملاً محرمانه اطلاعات نمرات روی حافظه دستگاه معلم</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl hover:bg-slate-100"
          >
            متوجه شدم
          </button>
        </div>
      </div>
    </div>
  );
};
