import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ReportsView } from './ReportsView';
import { NotesView } from './NotesView';
import { RemindersView } from './RemindersView';
import { BarChart3, FileText, Bell, Settings, ShieldCheck, Download, ChevronLeft, Smartphone } from 'lucide-react';
import { toPersianDigits } from '../utils/persian';

interface MoreViewProps {
  onOpenSettings: () => void;
  onOpenInstall: () => void;
}

export const MoreView: React.FC<MoreViewProps> = ({ onOpenSettings, onOpenInstall }) => {
  const { notes, reminders } = useApp();
  const [subSection, setSubSection] = useState<'menu' | 'reports' | 'notes' | 'reminders'>('menu');

  if (subSection === 'reports') {
    return (
      <div className="space-y-3">
        <button
          onClick={() => setSubSection('menu')}
          className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:underline mb-2"
        >
          <ChevronLeft className="w-4 h-4 rotate-180" />
          <span>بازگشت به منوی امکانات</span>
        </button>
        <ReportsView />
      </div>
    );
  }

  if (subSection === 'notes') {
    return (
      <div className="space-y-3">
        <button
          onClick={() => setSubSection('menu')}
          className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:underline mb-2"
        >
          <ChevronLeft className="w-4 h-4 rotate-180" />
          <span>بازگشت به منوی امکانات</span>
        </button>
        <NotesView />
      </div>
    );
  }

  if (subSection === 'reminders') {
    return (
      <div className="space-y-3">
        <button
          onClick={() => setSubSection('menu')}
          className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:underline mb-2"
        >
          <ChevronLeft className="w-4 h-4 rotate-180" />
          <span>بازگشت به منوی امکانات</span>
        </button>
        <RemindersView />
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 p-4 md:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white">
          امکانات و ابزارهای تکمیلی دفتر نمره
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          گزارش‌ها و نمودارها، یادداشت‌های آموزشی، تقویم یادآوری‌ها و تنظیمات پشتیبان‌گیری
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Reports & Charts */}
        <button
          onClick={() => setSubSection('reports')}
          className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 flex items-center justify-between text-right group shadow-2xs active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block group-hover:text-emerald-600 transition-colors">
                گزارش‌ها و نمودارهای تحلیلی
              </span>
              <span className="text-[11px] text-slate-400">
                توزیع نمرات، مقایسه نوبت اول و دوم، درصد حضور
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        {/* Notes */}
        <button
          onClick={() => setSubSection('notes')}
          className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 flex items-center justify-between text-right group shadow-2xs active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-800 dark:text-slate-100 group-hover:text-sky-600 transition-colors">
                  یادداشت‌های معلم
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-100 dark:bg-sky-900/60 text-sky-700 dark:text-sky-300">
                  {toPersianDigits(notes.length)}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                بودجه‌بندی تدریس، نکات کلاسی و دانش‌آموزان
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        {/* Reminders */}
        <button
          onClick={() => setSubSection('reminders')}
          className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 flex items-center justify-between text-right group shadow-2xs active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-800 dark:text-slate-100 group-hover:text-amber-600 transition-colors">
                  یادآوری‌ها و امتحانات
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300">
                  {toPersianDigits(reminders.filter((r) => !r.completed).length)} فعال
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                تاریخ امتحانات، ثبت سیدا، جلسه با اولیا
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        {/* Settings & Backup */}
        <button
          onClick={onOpenSettings}
          className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 flex items-center justify-between text-right group shadow-2xs active:scale-[0.99] transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block group-hover:text-teal-600 transition-colors">
                پشتیبان‌گیری و تنظیمات
              </span>
              <span className="text-[11px] text-slate-400">
                دانلود و بازیابی فایل JSON، اکسل، حالت شب و روز
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        {/* Install on Mobile Card */}
        <button
          onClick={onOpenInstall}
          className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 hover:border-emerald-500 flex items-center justify-between text-right group shadow-2xs active:scale-[0.99] transition-all sm:col-span-2"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-bold text-emerald-900 dark:text-emerald-100 block">
                نصب برنامه «دفتر نمره» روی موبایل (PWA)
              </span>
              <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                راهنمای نصب آسان روی آیفون و اندروید، اجرای آفلاین و دسترسی از صفحه اصلی
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-emerald-600" />
        </button>
      </div>
    </div>
  );
};
