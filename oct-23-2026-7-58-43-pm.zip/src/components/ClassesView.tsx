import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  Plus,
  School,
  BookOpen,
  Edit2,
  Trash2,
  Upload,
  Download,
  Search,
  UserPlus,
  X,
  FileSpreadsheet,
  Check,
  ChevronRight,
} from 'lucide-react';
import { toPersianDigits } from '../utils/persian';
import { ClassRoom } from '../types';

interface ClassesViewProps {
  onOpenAddStudent: () => void;
}

export const ClassesView: React.FC<ClassesViewProps> = ({ onOpenAddStudent }) => {
  const {
    classes,
    students,
    activeClassId,
    setActiveClassId,
    activeClass,
    addClass,
    updateClass,
    deleteClass,
    deleteStudent,
    batchAddStudents,
    setSelectedStudentProfileId,
    showToast,
  } = useApp();

  const [showAddClassModal, setShowAddClassModal] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassRoom | null>(null);
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [batchText, setBatchText] = useState('');
  const [searchStudent, setSearchStudent] = useState('');

  // Class Form State
  const [name, setName] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [grade, setGrade] = useState('دهم');
  const [field, setField] = useState('علوم تجربی');
  const [academicYear, setAcademicYear] = useState('۱۴۰۳-۱۴۰۴');
  const [subject, setSubject] = useState('زیست‌شناسی ۱');
  const [color, setColor] = useState('#059669');

  const openAddClass = () => {
    setEditingClass(null);
    setName('');
    setSchoolName(activeClass?.schoolName || 'دبیرستان ماندگار');
    setGrade('دهم');
    setField('علوم تجربی');
    setAcademicYear('۱۴۰۳-۱۴۰۴');
    setSubject('زیست‌شناسی');
    setColor('#059669');
    setShowAddClassModal(true);
  };

  const openEditClass = (cls: ClassRoom) => {
    setEditingClass(cls);
    setName(cls.name);
    setSchoolName(cls.schoolName);
    setGrade(cls.grade);
    setField(cls.field);
    setAcademicYear(cls.academicYear);
    setSubject(cls.subject);
    setColor(cls.color || '#059669');
    setShowAddClassModal(true);
  };

  const handleSaveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !schoolName.trim() || !subject.trim()) {
      showToast('لطفاً عنوان کلاس، نام مدرسه و درس را تکمیل فرمایید', 'error');
      return;
    }

    if (editingClass) {
      updateClass(editingClass.id, {
        name: name.trim(),
        schoolName: schoolName.trim(),
        grade,
        field,
        academicYear,
        subject: subject.trim(),
        color,
      });
    } else {
      addClass({
        name: name.trim(),
        schoolName: schoolName.trim(),
        grade,
        field,
        academicYear,
        subject: subject.trim(),
        color,
        gradingConfig: {
          type: 'standard_iranian',
          continuousTerm1Weight: 1,
          finalTerm1Weight: 2,
          continuousTerm2Weight: 1,
          finalTerm2Weight: 4,
          passingThreshold: 10,
        },
      });
    }

    setShowAddClassModal(false);
  };

  const handleBatchImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClass) return;
    if (!batchText.trim()) {
      showToast('لطفاً اسامی دانش‌آموزان را وارد نمایید', 'error');
      return;
    }
    const count = batchAddStudents(activeClass.id, batchText);
    if (count > 0) {
      setBatchText('');
      setShowBatchModal(false);
    }
  };

  const classStudents = students.filter((s) => s.classId === activeClass?.id);
  const filteredStudents = classStudents.filter((s) => {
    if (!searchStudent.trim()) return true;
    const q = searchStudent.toLowerCase().trim();
    return (
      `${s.firstName} ${s.lastName}`.toLowerCase().includes(q) ||
      s.nationalCode.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-200">
      {/* Classes Carousel / Selector */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <School className="w-4 h-4 text-emerald-600" />
            <span>کلاس‌های من</span>
          </h2>
          <button
            onClick={openAddClass}
            className="flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>تعریف کلاس جدید</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {classes.map((cls) => {
            const count = students.filter((s) => s.classId === cls.id).length;
            const isSelected = cls.id === activeClassId;

            return (
              <div
                key={cls.id}
                onClick={() => setActiveClassId(cls.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative ${
                  isSelected
                    ? 'bg-emerald-50/60 dark:bg-emerald-950/30 border-emerald-500 ring-2 ring-emerald-500/20'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      {cls.name}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      {cls.schoolName}
                    </span>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400 block">
                      {cls.subject} · پایه {cls.grade} ({cls.field})
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openEditClass(cls);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                      title="ویرایش کلاس"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {classes.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`آیا از حذف کلاس «${cls.name}» اطمینان دارید؟`)) {
                            deleteClass(cls.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                        title="حذف کلاس"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                  <span>{toPersianDigits(count)} دانش‌آموز</span>
                  <span className="text-[10px] text-slate-400">{cls.academicYear}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Class Student Management Section */}
      {activeClass && (
        <div className="space-y-3 bg-white dark:bg-slate-900 p-4 md:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-600" />
                <span>دانش‌آموزان {activeClass.name}</span>
                <span className="text-xs font-normal text-slate-400">
                  ({toPersianDigits(classStudents.length)} نفر)
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                با کلیک بر روی هر دانش‌آموز، شناسنامه و کارنامه کامل او باز خواهد شد.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowBatchModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>ورود دسته‌جمعی</span>
              </button>

              <button
                onClick={onOpenAddStudent}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>افزودن دانش‌آموز</span>
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <input
              type="text"
              value={searchStudent}
              onChange={(e) => setSearchStudent(e.target.value)}
              placeholder="جستجو در بین دانش‌آموزان این کلاس..."
              className="w-full text-xs py-2 ps-8 pe-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2" />
          </div>

          {/* Students List */}
          {filteredStudents.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              {searchStudent ? 'دانش‌آموزی با این مشخصات یافت نشد.' : 'هنوز دانش‌آموزی در این کلاس ثبت نشده است.'}
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredStudents.map((student, idx) => (
                <div
                  key={student.id}
                  onClick={() => setSelectedStudentProfileId(student.id)}
                  className="py-3 px-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40 rounded-xl cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold flex items-center justify-center">
                      {toPersianDigits(idx + 1)}
                    </span>
                    <div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block group-hover:text-emerald-600 transition-colors">
                        {student.firstName} {student.lastName}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        کد ملی / دانش‌آموزی: {toPersianDigits(student.nationalCode) || 'ندارد'}
                        {student.phone && ` · تماس: ${toPersianDigits(student.phone)}`}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                      مشاهده پرونده
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400 rotate-180" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal: Add or Edit Class */}
      {showAddClassModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white">
                {editingClass ? 'ویرایش کلاس' : 'ایجاد کلاس جدید'}
              </h2>
              <button onClick={() => setShowAddClassModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveClass} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">نام یا کد کلاس</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثلاً: کلاس ۱۰۱ تجربی یا کلاس دوازدهم الف"
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-500 mb-1">نام مدرسه / دبیرستان</label>
                <input
                  type="text"
                  value={schoolName}
                  onChange={(e) => setSchoolName(e.target.value)}
                  placeholder="مثلاً: دبیرستان ماندگار بهشتی"
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">پایه تحصیلی</label>
                  <select
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  >
                    <option value="دهم">دهم</option>
                    <option value="یازدهم">یازدهم</option>
                    <option value="دوازدهم">دوازدهم</option>
                    <option value="نهم">نهم</option>
                    <option value="هشتم">هشتم</option>
                    <option value="هفتم">هفتم</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">رشته تحصیلی</label>
                  <select
                    value={field}
                    onChange={(e) => setField(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  >
                    <option value="علوم تجربی">علوم تجربی</option>
                    <option value="ریاضی و فیزیک">ریاضی و فیزیک</option>
                    <option value="ادبیات و علوم انسانی">ادبیات و علوم انسانی</option>
                    <option value="فنی و حرفه‌ای">فنی و حرفه‌ای</option>
                    <option value="کار دانش">کار دانش</option>
                    <option value="علوم و معارف اسلامی">علوم و معارف اسلامی</option>
                    <option value="عمومی">عمومی (متوسطه اول)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">نام درس / عنوان کتاب</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="مثلاً: زیست‌شناسی ۱"
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">سال تحصیلی</label>
                  <input
                    type="text"
                    value={academicYear}
                    onChange={(e) => setAcademicYear(e.target.value)}
                    placeholder="۱۴۰۳-۱۴۰۴"
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddClassModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-medium bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
                >
                  {editingClass ? 'ذخیره تغییرات' : 'ایجاد کلاس'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Batch Add Students */}
      {showBatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-lg w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>ورود دسته‌جمعی اسامی دانش‌آموزان</span>
              </h2>
              <button onClick={() => setShowBatchModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              اسامی دانش‌آموزان را از فایل اکسل، برنامه شاد یا سامانه سیدا کپی کرده و در کادر زیر جای‌گذاری (Paste) کنید. هر سطر یک دانش‌آموز:
              <br />
              <code className="text-[10px] bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-emerald-600">
                علی رضایی
              </code> یا <code className="text-[10px] bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-emerald-600">
                ۱۲۳۴۵۶۷۸۹۰, امیرحسین, محمدی
              </code>
            </p>

            <form onSubmit={handleBatchImport} className="space-y-3">
              <textarea
                value={batchText}
                onChange={(e) => setBatchText(e.target.value)}
                rows={8}
                placeholder="علی رضایی&#10;محمد کریمی&#10;سینا ابراهیمی&#10;پارسا علیزاده"
                className="w-full text-xs p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none leading-relaxed"
                required
              />

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBatchModal(false)}
                  className="px-4 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-medium bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
                >
                  افزودن به کلاس
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
