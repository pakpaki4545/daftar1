import React from 'react';
import { useApp } from '../context/AppContext';
import { BarChart3, TrendingUp, Users, Award, CalendarCheck, ThumbsUp, ThumbsDown, CheckCircle2 } from 'lucide-react';
import { calculateAnnualScore, calculateTerm1Score, calculateTerm2Score, formatScore, toPersianDigits } from '../utils/persian';

export const ReportsView: React.FC = () => {
  const { activeClass, students, grades, attendance } = useApp();

  if (!activeClass) {
    return <div className="p-8 text-center text-slate-500">کلاسی انتخاب نشده است.</div>;
  }

  const classStudents = students.filter((s) => s.classId === activeClass.id);
  const classGrades = grades.filter((g) => g.classId === activeClass.id);
  const classAttendance = attendance.filter((a) => a.classId === activeClass.id);

  // Score distribution counts
  let excellent = 0; // 18 - 20
  let good = 0;      // 15 - 17.99
  let medium = 0;    // 10 - 14.99
  let low = 0;       // < 10

  let sumAnnual = 0;
  let countAnnual = 0;
  let sumT1 = 0;
  let countT1 = 0;
  let sumT2 = 0;
  let countT2 = 0;

  let maxScore = -1;
  let minScore = 999;
  let totalPositive = 0;
  let totalNegative = 0;

  classStudents.forEach((st) => {
    const g = classGrades.find((gr) => gr.studentId === st.id);
    const ann = calculateAnnualScore(g, activeClass.gradingConfig);
    const t1 = calculateTerm1Score(g);
    const t2 = calculateTerm2Score(g);

    if (g?.positiveScores) totalPositive += g.positiveScores;
    if (g?.negativeScores) totalNegative += g.negativeScores;

    if (ann !== null) {
      sumAnnual += ann;
      countAnnual++;
      if (ann > maxScore) maxScore = ann;
      if (ann < minScore) minScore = ann;

      if (ann >= 18) excellent++;
      else if (ann >= 15) good++;
      else if (ann >= 10) medium++;
      else low++;
    }

    if (t1 !== null) {
      sumT1 += t1;
      countT1++;
    }
    if (t2 !== null) {
      sumT2 += t2;
      countT2++;
    }
  });

  const avgAnnual = countAnnual > 0 ? (sumAnnual / countAnnual).toFixed(2) : '-';
  const avgT1 = countT1 > 0 ? (sumT1 / countT1).toFixed(2) : '-';
  const avgT2 = countT2 > 0 ? (sumT2 / countT2).toFixed(2) : '-';

  // Attendance rate
  let totalRecords = 0;
  let presentRecords = 0;
  classAttendance.forEach((sess) => {
    Object.values(sess.records).forEach((st) => {
      totalRecords++;
      if (st === 'present') presentRecords++;
      else if (st === 'late') presentRecords += 0.75;
    });
  });
  const attendanceRate = totalRecords > 0 ? Math.round((presentRecords / totalRecords) * 100) : 100;

  // Max count for distribution scale
  const maxCategoryCount = Math.max(excellent, good, medium, low, 1);

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-4 md:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-emerald-600" />
          <span>آمار و گزارش تحلیلی: {activeClass.name}</span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          بررسی توزیع نمرات کلاسی، مقایسه نوبت اول و دوم، نرخ حضور و تعامل دانش‌آموزان
        </p>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">میانگین سالانه کلاس</span>
          <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
            {formatScore(avgAnnual === '-' ? null : Number(avgAnnual))}
          </span>
          <span className="text-[10px] text-slate-400 block mt-1">از ۲۰ نمره</span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">بالاترین نمره کلاس</span>
          <span className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {maxScore >= 0 ? formatScore(maxScore) : '-'}
          </span>
          <span className="text-[10px] text-emerald-600 block mt-1">حداکثر بازدهی</span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">پایین‌ترین نمره کلاس</span>
          <span className="text-2xl font-black text-rose-600 tabular-nums">
            {minScore <= 20 && minScore >= 0 ? formatScore(minScore) : '-'}
          </span>
          <span className="text-[10px] text-rose-500 block mt-1">نیاز به پیگیری</span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">شاخص حضور کل</span>
          <span className="text-2xl font-black text-teal-600 tabular-nums">
            {toPersianDigits(attendanceRate)}٪
          </span>
          <span className="text-[10px] text-slate-400 block mt-1">
            {toPersianDigits(classAttendance.length)} جلسه برگزار شده
          </span>
        </div>
      </div>

      {/* Grade Distribution Histogram */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xs md:text-sm font-bold text-slate-800 dark:text-slate-100">
              توزیع فراوانی نمرات دانش‌آموزان
            </h2>
            <p className="text-[11px] text-slate-400">
              دسته‌بندی نمرات بر اساس سطوح عملکردی آموزش و پرورش
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {toPersianDigits(countAnnual)} از {toPersianDigits(classStudents.length)} نمره ثبت شده
          </span>
        </div>

        <div className="space-y-3 pt-2">
          {/* Level 1: 18 - 20 */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-emerald-700 dark:text-emerald-300">عالی و خیلی خوب (۱۸ تا ۲۰)</span>
              <span className="tabular-nums">{toPersianDigits(excellent)} نفر ({toPersianDigits(countAnnual > 0 ? Math.round((excellent / countAnnual) * 100) : 0)}٪)</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${(excellent / maxCategoryCount) * 100}%` }}
              />
            </div>
          </div>

          {/* Level 2: 15 - 17.99 */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-sky-700 dark:text-sky-300">خوب (۱۵ تا ۱۷/۹۹)</span>
              <span className="tabular-nums">{toPersianDigits(good)} نفر ({toPersianDigits(countAnnual > 0 ? Math.round((good / countAnnual) * 100) : 0)}٪)</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-sky-500 rounded-full transition-all duration-500"
                style={{ width: `${(good / maxCategoryCount) * 100}%` }}
              />
            </div>
          </div>

          {/* Level 3: 10 - 14.99 */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-amber-700 dark:text-amber-300">متوسط و قابل قبول (۱۰ تا ۱۴/۹۹)</span>
              <span className="tabular-nums">{toPersianDigits(medium)} نفر ({toPersianDigits(countAnnual > 0 ? Math.round((medium / countAnnual) * 100) : 0)}٪)</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${(medium / maxCategoryCount) * 100}%` }}
              />
            </div>
          </div>

          {/* Level 4: < 10 */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-rose-700 dark:text-rose-300">نیازمند تلاش و تجدید (زیر ۱۰)</span>
              <span className="tabular-nums">{toPersianDigits(low)} نفر ({toPersianDigits(countAnnual > 0 ? Math.round((low / countAnnual) * 100) : 0)}٪)</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-rose-500 rounded-full transition-all duration-500"
                style={{ width: `${(low / maxCategoryCount) * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Term Comparison & Classroom Activity Ratio */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Term 1 vs Term 2 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h2 className="text-xs md:text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>مقایسه میانگین نوبت اول و دوم</span>
          </h2>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block">نوبت اول (دی)</span>
              <span className="text-xl font-black text-slate-800 dark:text-slate-200 tabular-nums">
                {avgT1 !== '-' ? formatScore(Number(avgT1)) : '-'}
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block">نوبت دوم (خرداد)</span>
              <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                {avgT2 !== '-' ? formatScore(Number(avgT2)) : '-'}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {avgT1 !== '-' && avgT2 !== '-' ? (
              Number(avgT2) >= Number(avgT1) ? (
                <span className="text-emerald-600 font-medium">
                  میانگین نوبت دوم کلاس نسبت به نوبت اول رشد داشته است (+{formatScore(Number(avgT2) - Number(avgT1))})
                </span>
              ) : (
                <span className="text-amber-600 font-medium">
                  میانگین نوبت دوم کلاس اندکی نسبت به نوبت اول کاهش یافته است (-{formatScore(Number(avgT1) - Number(avgT2))})
                </span>
              )
            ) : (
              'پس از ثبت نمرات هر دو نوبت، مقایسه دقیق پیشرفت تحصیلی نمایش داده خواهد شد.'
            )}
          </p>
        </div>

        {/* Positive & Negative Scores Summary */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h2 className="text-xs md:text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-600" />
            <span>شاخص فعالیت و مشارکت کلاسی</span>
          </h2>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-center space-y-1 border border-emerald-200/50 dark:border-emerald-800/50">
              <span className="text-[11px] text-emerald-700 dark:text-emerald-300 block">
                مجموع نمرات مثبت (+)
              </span>
              <span className="text-2xl font-black text-emerald-700 dark:text-emerald-300 tabular-nums">
                {toPersianDigits(totalPositive)}
              </span>
            </div>

            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl text-center space-y-1 border border-rose-200/50 dark:border-rose-800/50">
              <span className="text-[11px] text-rose-700 dark:text-rose-300 block">
                مجموع نمرات منفی (-)
              </span>
              <span className="text-2xl font-black text-rose-700 dark:text-rose-300 tabular-nums">
                {toPersianDigits(totalNegative)}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            نسبت نمرات مثبت به منفی نشان‌دهنده انگیزه و پویایی بالای کلاسی است.
          </p>
        </div>
      </div>
    </div>
  );
};
