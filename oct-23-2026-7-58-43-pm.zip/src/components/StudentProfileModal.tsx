import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, User, Phone, Hash, Award, Calendar, Plus, Minus, FileText, CheckCircle2, XCircle, Clock, AlertCircle, Edit3, Trash2, Printer } from 'lucide-react';
import { calculateAnnualScore, calculateTerm1Score, calculateTerm2Score, formatScore, getScoreBadge, toPersianDigits } from '../utils/persian';

interface StudentProfileModalProps {
  studentId: string;
  onClose: () => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({ studentId, onClose }) => {
  const {
    students,
    classes,
    grades,
    customScores,
    attendance,
    notes,
    updateStudent,
    deleteStudent,
    adjustPositiveScore,
    adjustNegativeScore,
    showToast,
  } = useApp();

  const student = students.find((s) => s.id === studentId);
  const studentClass = classes.find((c) => c.id === student?.classId);
  const gradeRecord = grades.find((g) => g.studentId === studentId && g.classId === student?.classId);
  const studentCustomScores = customScores.filter((cs) => cs.studentId === studentId && cs.classId === student?.classId);
  const studentNotes = notes.filter((n) => n.studentId === studentId);

  // Edit Mode state
  const [isEditing, setIsEditing] = useState(false);
  const [editFirstName, setEditFirstName] = useState(student?.firstName || '');
  const [editLastName, setEditLastName] = useState(student?.lastName || '');
  const [editNationalCode, setEditNationalCode] = useState(student?.nationalCode || '');
  const [editPhone, setEditPhone] = useState(student?.phone || '');
  const [editNotes, setEditNotes] = useState(student?.notes || '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  if (!student) return null;

  // Attendance stats for this student
  const classSessions = attendance.filter((a) => a.classId === student.classId);
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let excusedCount = 0;

  classSessions.forEach((session) => {
    const status = session.records[studentId];
    if (status === 'present') presentCount++;
    else if (status === 'absent') absentCount++;
    else if (status === 'late') lateCount++;
    else if (status === 'excused') excusedCount++;
  });

  const totalMarked = presentCount + absentCount + lateCount + excusedCount;
  const attendanceRate = totalMarked > 0 ? Math.round(((presentCount + (lateCount * 0.75)) / totalMarked) * 100) : 100;

  // Calculated Grades
  const t1Score = calculateTerm1Score(gradeRecord);
  const t2Score = calculateTerm2Score(gradeRecord);
  const annualScore = calculateAnnualScore(gradeRecord, studentClass?.gradingConfig);
  const annualBadge = getScoreBadge(annualScore);

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFirstName.trim() || !editLastName.trim()) {
      showToast('نام و نام خانوادگی را وارد نمایید', 'error');
      return;
    }
    updateStudent(student.id, {
      firstName: editFirstName.trim(),
      lastName: editLastName.trim(),
      nationalCode: editNationalCode.trim(),
      phone: editPhone.trim(),
      notes: editNotes.trim(),
    });
    setIsEditing(false);
  };

  const handleDelete = () => {
    deleteStudent(student.id);
    onClose();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-900/70">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-lg">
              {student.firstName[0]}
            </div>
            <div>
              <h2 className="font-bold text-base md:text-lg text-slate-900 dark:text-white">
                {student.firstName} {student.lastName}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {studentClass?.name} · {studentClass?.schoolName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrint}
              title="چاپ کارنامه کلاسی"
              className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsEditing(!isEditing)}
              title="ویرایش مشخصات"
              className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body content (scrollable) */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Edit Form or Information Card */}
          {isEditing ? (
            <form onSubmit={handleSaveEdit} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-3 border border-slate-200 dark:border-slate-700">
              <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300">ویرایش مشخصات دانش‌آموز</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">نام</label>
                  <input
                    type="text"
                    value={editFirstName}
                    onChange={(e) => setEditFirstName(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">نام خانوادگی</label>
                  <input
                    type="text"
                    value={editLastName}
                    onChange={(e) => setEditLastName(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">کد دانش‌آموزی / کد ملی</label>
                  <input
                    type="text"
                    value={editNationalCode}
                    onChange={(e) => setEditNationalCode(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">شماره تماس ولی / دانش‌آموز</label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">یادداشت دبیر</label>
                <textarea
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  rows={2}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 font-medium"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف دانش‌آموز</span>
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    انصراف
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700"
                  >
                    ذخیره تغییرات
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <span className="text-slate-400 block mb-1">کد دانش‌آموزی</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">
                  {toPersianDigits(student.nationalCode) || 'ثبت نشده'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <span className="text-slate-400 block mb-1">شماره تماس</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200" dir="ltr">
                  {toPersianDigits(student.phone) || 'ثبت نشده'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <span className="text-slate-400 block mb-1">نمره سالانه</span>
                <span className={`font-bold text-sm ${annualBadge.colorClass}`}>
                  {formatScore(annualScore)}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <span className="text-slate-400 block mb-1">درصد حضور</span>
                <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">
                  {toPersianDigits(attendanceRate)}٪
                </span>
              </div>
            </div>
          )}

          {/* Delete Confirmation Alert */}
          {showDeleteConfirm && (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-rose-800 dark:text-rose-200">
                  آیا از حذف این دانش‌آموز اطمینان دارید؟
                </p>
                <p className="text-[11px] text-rose-600 dark:text-rose-400">
                  تمام نمرات و سوابق حضور این دانش‌آموز نیز حذف خواهند شد.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1.5 text-xs bg-white dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300"
                >
                  انصراف
                </button>
                <button
                  onClick={handleDelete}
                  className="px-3 py-1.5 text-xs bg-rose-600 text-white rounded-lg font-medium hover:bg-rose-700"
                >
                  حذف قطعی
                </button>
              </div>
            </div>
          )}

          {/* Positive & Negative Scores Section */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                ارزیابی فعالیت و انضباط کلاسی
              </span>
              <span className="text-[11px] text-slate-500">
                ثبت مثبت (+) و منفی (-) برای پرسش، حل تمرین و رفتار در کلاس
              </span>
            </div>
            <div className="flex items-center gap-4">
              {/* Positive */}
              <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800">
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                  {toPersianDigits(gradeRecord?.positiveScores || 0)} مثبت
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => adjustPositiveScore(student.id, student.classId, -1)}
                    className="w-5 h-5 rounded bg-emerald-200 dark:bg-emerald-800 hover:bg-emerald-300 text-emerald-800 dark:text-emerald-100 flex items-center justify-center text-xs"
                  >
                    -
                  </button>
                  <button
                    onClick={() => adjustPositiveScore(student.id, student.classId, 1)}
                    className="w-5 h-5 rounded bg-emerald-600 text-white hover:bg-emerald-700 flex items-center justify-center text-xs"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Negative */}
              <div className="flex items-center gap-1.5 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1.5 rounded-lg border border-rose-200 dark:border-rose-800">
                <span className="text-xs font-bold text-rose-700 dark:text-rose-300">
                  {toPersianDigits(gradeRecord?.negativeScores || 0)} منفی
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => adjustNegativeScore(student.id, student.classId, -1)}
                    className="w-5 h-5 rounded bg-rose-200 dark:bg-rose-800 hover:bg-rose-300 text-rose-800 dark:text-rose-100 flex items-center justify-center text-xs"
                  >
                    -
                  </button>
                  <button
                    onClick={() => adjustNegativeScore(student.id, student.classId, 1)}
                    className="w-5 h-5 rounded bg-rose-600 text-white hover:bg-rose-700 flex items-center justify-center text-xs"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Complete Grades Breakdown Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>ریز نمرات و کارنامه کلاسی</span>
            </h3>

            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs">
              <table className="w-full text-right">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  <tr>
                    <th className="py-2.5 px-3">بخش ارزیابی</th>
                    <th className="py-2.5 px-3">مستمر (از ۲۰)</th>
                    <th className="py-2.5 px-3">پایانی (از ۲۰)</th>
                    <th className="py-2.5 px-3">نتیجه نهایی</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                  <tr>
                    <td className="py-2.5 px-3 font-medium">نوبت اول (دی‌ماه)</td>
                    <td className="py-2.5 px-3 font-semibold">{formatScore(gradeRecord?.continuousTerm1)}</td>
                    <td className="py-2.5 px-3 font-semibold">{formatScore(gradeRecord?.finalTerm1)}</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">
                      {formatScore(t1Score)}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-medium">نوبت دوم (خرداد‌ماه)</td>
                    <td className="py-2.5 px-3 font-semibold">{formatScore(gradeRecord?.continuousTerm2)}</td>
                    <td className="py-2.5 px-3 font-semibold">{formatScore(gradeRecord?.finalTerm2)}</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">
                      {formatScore(t2Score)}
                    </td>
                  </tr>
                  <tr className="bg-slate-50 dark:bg-slate-800/40 font-bold">
                    <td className="py-3 px-3">نمره سالانه کل</td>
                    <td colSpan={2} className="py-3 px-3 text-slate-500 font-normal">
                      طبق فرمول آموزش و پرورش
                    </td>
                    <td className="py-3 px-3">
                      <span className={`text-sm ${annualBadge.colorClass}`}>
                        {formatScore(annualScore)}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Custom Tests & Activities */}
          {studentCustomScores.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                کوییزها و فعالیت‌های کلاسی
              </h3>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs">
                {studentCustomScores.map((cs) => (
                  <div key={cs.id} className="p-3 flex items-center justify-between bg-white dark:bg-slate-900">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                        {cs.title}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {toPersianDigits(cs.date)} · {cs.description || (cs.term === 'term1' ? 'نوبت اول' : 'نوبت دوم')}
                      </span>
                    </div>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      {toPersianDigits(cs.score)} از {toPersianDigits(cs.maxScore)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Attendance History */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <span>وضعیت حضور و غیاب</span>
              </h3>
              <div className="flex items-center gap-3 text-[11px]">
                <span className="text-emerald-600 font-medium">{toPersianDigits(presentCount)} حاضر</span>
                <span className="text-rose-600 font-medium">{toPersianDigits(absentCount)} غایب</span>
                <span className="text-amber-600 font-medium">{toPersianDigits(lateCount)} تأخیر</span>
                <span className="text-sky-600 font-medium">{toPersianDigits(excusedCount)} موجه</span>
              </div>
            </div>

            {classSessions.length === 0 ? (
              <p className="text-xs text-slate-400 p-3 bg-slate-50 dark:bg-slate-800/30 rounded-xl text-center">
                هنوز جلسه‌ای برای این کلاس ثبت نشده است.
              </p>
            ) : (
              <div className="max-h-48 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {classSessions.map((session) => {
                  const status = session.records[student.id] || 'present';
                  return (
                    <div key={session.id} className="p-2.5 px-3 flex items-center justify-between">
                      <div>
                        <span className="font-medium text-slate-700 dark:text-slate-300 block">
                          {toPersianDigits(session.date)} ({toPersianDigits(session.time)})
                        </span>
                        {session.topic && (
                          <span className="text-[11px] text-slate-400 truncate max-w-xs block">
                            {session.topic}
                          </span>
                        )}
                      </div>
                      <span
                        className={`text-[11px] font-medium px-2 py-0.5 rounded ${
                          status === 'present'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : status === 'absent'
                            ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                            : status === 'late'
                            ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                            : 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                        }`}
                      >
                        {status === 'present'
                          ? 'حاضر'
                          : status === 'absent'
                          ? 'غایب'
                          : status === 'late'
                          ? 'تأخیر'
                          : 'موجه'}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Student Specific Notes */}
          {(student.notes || studentNotes.length > 0) && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>یادداشت‌های اختصاصی معلم</span>
              </h3>
              {student.notes && (
                <div className="p-3 bg-amber-50/60 dark:bg-amber-950/30 rounded-xl border border-amber-200/50 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-200">
                  {student.notes}
                </div>
              )}
              {studentNotes.map((n) => (
                <div key={n.id} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs space-y-1">
                  <div className="flex justify-between text-slate-400 text-[10px]">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{n.title}</span>
                    <span>{toPersianDigits(n.date)}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300">{n.content}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl hover:bg-slate-100"
          >
            بستن پرونده
          </button>
        </div>
      </div>
    </div>
  );
};
