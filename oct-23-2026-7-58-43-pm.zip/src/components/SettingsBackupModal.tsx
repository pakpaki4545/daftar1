import React, { useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Settings,
  Download,
  Upload,
  RotateCcw,
  Sun,
  Moon,
  FileSpreadsheet,
  BookOpen,
  Info,
  ShieldCheck,
} from 'lucide-react';

interface SettingsBackupModalProps {
  onClose: () => void;
}

export const SettingsBackupModal: React.FC<SettingsBackupModalProps> = ({ onClose }) => {
  const {
    isDarkMode,
    toggleDarkMode,
    exportBackupJSON,
    importBackupJSON,
    resetToSampleData,
    activeClass,
    exportClassGradesToCSV,
    showToast,
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importBackupJSON(content);
        if (success) {
          onClose();
        }
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('آیا از بازگردانی اطلاعات نمونه اولیه اطمینان دارید؟ اطلاعات فعلی جایگزین خواهند شد.')) {
      resetToSampleData();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-lg w-full max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900">
          <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Settings className="w-4 h-4 text-emerald-600" />
            <span>تنظیمات، پشتیبان‌گیری و راهنما</span>
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          {/* Theme Mode */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                حالت نمایش تاریک (Dark Mode)
              </span>
              <span className="text-[11px] text-slate-400">
                مناسب کار در کلاس‌های با نور کم یا تخته هوشمند
              </span>
            </div>

            <button
              onClick={toggleDarkMode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium"
            >
              {isDarkMode ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>حالت روز</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5" />
                  <span>حالت شب</span>
                </>
              )}
            </button>
          </div>

          {/* Backup & Restore Section */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>پشتیبان‌گیری و ذخیره امن داده‌ها</span>
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              کلیه اطلاعات شامل نمرات، غیبت‌ها، یادداشت‌ها و کلاس‌ها به صورت آفلاین در دستگاه شما ذخیره می‌شوند. برای جلوگیری از پاک شدن ناخواسته حافظه مرورگر، نسخه پشتیبان تهیه نمایید.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                onClick={exportBackupJSON}
                className="flex items-center justify-center gap-2 p-3 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold hover:bg-emerald-100 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>دانلود فایل پشتیبان (JSON)</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>بازیابی از فایل پشتیبان</span>
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".json"
                className="hidden"
              />
            </div>
          </div>

          {/* Excel Export */}
          {activeClass && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  خروجی نمرات کلاس {activeClass.name}
                </span>
                <span className="text-[11px] text-slate-400">
                  سازگار با نرم‌افزار مایکروسافت اکسل و سامانه سیدا
                </span>
              </div>
              <button
                onClick={() => exportClassGradesToCSV(activeClass.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>دانلود اکسل</span>
              </button>
            </div>
          )}

          {/* Educational Rules & Tips */}
          <div className="p-4 bg-amber-50/60 dark:bg-amber-950/30 rounded-xl border border-amber-200/50 dark:border-amber-900/50 space-y-1.5 text-amber-900 dark:text-amber-200">
            <span className="font-bold flex items-center gap-1.5">
              <Info className="w-4 h-4 shrink-0 text-amber-600" />
              <span>قوانین و راهنمای ثبت نمره در مدارس</span>
            </span>
            <ul className="list-disc list-inside space-y-1 text-[11px] leading-relaxed text-amber-800 dark:text-amber-300">
              <li>دامنه مجاز نمرات از ۰ تا ۲۰ بوده و ضرایب ۰/۲۵ و ۰/۵ پذیرفته می‌شوند.</li>
              <li>فرمول نمره سالانه آموزش و پرورش: (پایانی۲×۴ + مستمر۲×۱ + پایانی۱×۲ + مستمر۱×۱) تقسیم بر ۸.</li>
              <li>در جدول نمرات، ستون نام دانش‌آموزان هنگام اسکرول افقی ثابت (Sticky) می‌ماند.</li>
              <li>با فشردن کلید Tab یا Enter در فیلدهای نمره می‌توانید به سرعت بین خانه‌ها جابه‌جا شوید.</li>
            </ul>
          </div>

          {/* Reset sample data */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div>
              <span className="font-bold text-rose-600 block">بازگردانی داده‌های پیش‌فرض</span>
              <span className="text-[10px] text-slate-400">نمونه اطلاعات کلاس‌های دهم و یازدهم</span>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 p-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>بازنشانی به نمونه</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl hover:bg-slate-100"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
