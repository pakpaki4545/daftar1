import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  Award,
  CalendarCheck,
  Bell,
  Plus,
  BookOpen,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  Sparkles,
  Check,
  ChevronLeft,
  Smartphone,
} from 'lucide-react';
import {
  calculateAnnualScore,
  calculateTerm1Score,
  formatScore,
  getScoreBadge,
  getTodayJalaliFormatted,
  toPersianDigits,
} from '../utils/persian';

interface DashboardViewProps {
  onOpenAddStudent: () => void;
  onOpenAddReminder: () => void;
  onOpenAddNote: () => void;
  onOpenNewSession: () => void;
  onOpenInstall: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenAddStudent,
  onOpenAddReminder,
  onOpenAddNote,
  onOpenNewSession,
  onOpenInstall,
}) => {
  const {
    classes,
    students,
    grades,
    attendance,
    reminders,
    activeClass,
    setActiveTab,
    toggleReminderComplete,
    setSelectedStudentProfileId,
  } = useApp();

  const today = getTodayJalaliFormatted();

  // Class specific students & stats
  const classStudents = students.filter((s) => s.classId === activeClass?.id);
  const classGrades = grades.filter((g) => g.classId === activeClass?.id);
  const classAttendance = attendance.filter((a) => a.classId === activeClass?.id);

  // Calculate class average
  let totalAnnual = 0;
  let countWithScores = 0;
  classGrades.forEach((g) => {
    const ann = calculateAnnualScore(g, activeClass?.gradingConfig);
    if (ann !== null) {
      totalAnnual += ann;
      countWithScores++;
    }
  });
  const classAverage = countWithScores > 0 ? (totalAnnual / countWithScores).toFixed(2) : null;

  // Attendance rate
  let totalRecords = 0;
  let presentRecords = 0;
  classAttendance.forEach((sess) => {
    Object.values(sess.records).forEach((st) => {
      totalRecords++;
      if (st === 'present') presentRecords++;
      else if (st === 'late') presentRecords += 0.75;
    });
  });
  const classAttendanceRate = totalRecords > 0 ? Math.round((presentRecords / totalRecords) * 100) : 100;

  // Upcoming Reminders
  const activeReminders = reminders.filter((r) => !r.completed);
  const upcomingReminders = activeReminders.slice(0, 4);

  // Top Achievers and Need Attention
  const studentRanked = classStudents
    .map((s) => {
      const g = classGrades.find((gr) => gr.studentId === s.id);
      const ann = calculateAnnualScore(g, activeClass?.gradingConfig);
      return { student: s, grade: g, score: ann };
    })
    .filter((item) => item.score !== null)
    .sort((a, b) => (b.score || 0) - (a.score || 0));

  const topStudents = studentRanked.slice(0, 3);
  const lowStudents = studentRanked.filter((s) => (s.score || 0) < 12).reverse().slice(0, 2);

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-l from-emerald-600 via-emerald-700 to-teal-800 rounded-3xl p-5 md:p-6 text-white shadow-lg shadow-emerald-900/10">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-emerald-100 text-xs font-medium bg-white/10 px-3 py-1 rounded-full backdrop-blur-sm">
              {today.fullString}
            </span>
            <span className="text-xs text-emerald-200">
              سال تحصیلی {activeClass?.academicYear || '۱۴۰۳-۱۴۰۴'}
            </span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pt-1">
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-tight text-white">
                دفتر کلاسی {activeClass?.name || 'کلاس من'}
              </h1>
              <p className="text-xs md:text-sm text-emerald-100 max-w-lg leading-relaxed mt-1">
                مدرسه {activeClass?.schoolName} · درس {activeClass?.subject} · پایه {activeClass?.grade} ({activeClass?.field})
              </p>
            </div>
            <button
              onClick={onOpenInstall}
              className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-white text-emerald-800 hover:bg-emerald-50 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all active:scale-[0.98] shrink-0"
            >
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span>نصب برنامه روی گوشی</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Action Hub for Fast One-Handed Classroom Use */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold text-slate-500 dark:text-slate-400">
          دسترسی سریع کلاسی
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={() => setActiveTab('gradebook')}
            className="flex items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs transition-all text-right group active:scale-[0.98]"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                ورود به دفتر نمره
              </span>
              <span className="text-[10px] text-slate-400">ثبت نمرات و مثبت/منفی</span>
            </div>
          </button>

          <button
            onClick={onOpenNewSession}
            className="flex items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs transition-all text-right group active:scale-[0.98]"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                حضور و غیاب امروز
              </span>
              <span className="text-[10px] text-slate-400">ثبت جلسه و وضعیت غایبین</span>
            </div>
          </button>

          <button
            onClick={onOpenAddStudent}
            className="flex items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs transition-all text-right group active:scale-[0.98]"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                دانش‌آموز جدید
              </span>
              <span className="text-[10px] text-slate-400">افزودن فردی یا گروهی</span>
            </div>
          </button>

          <button
            onClick={onOpenAddReminder}
            className="flex items-center gap-3 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs transition-all text-right group active:scale-[0.98]"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                یادآوری جدید
              </span>
              <span className="text-[10px] text-slate-400">امتحان، تکلیف، جلسات</span>
            </div>
          </button>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-2">
            <span>دانش‌آموزان کلاس</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {toPersianDigits(classStudents.length)}
            <span className="text-xs font-normal text-slate-400 ms-1">نفر</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            در کلاس {activeClass?.name}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-2">
            <span>میانگین نمرات کلاس</span>
            <Award className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {formatScore(classAverage ? Number(classAverage) : null)}
            <span className="text-xs font-normal text-slate-400 ms-1">از ۲۰</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            بر اساس نمره سالانه محاسبه شده
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-2">
            <span>درصد حضور کل</span>
            <CalendarCheck className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {toPersianDigits(classAttendanceRate)}٪
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            در {toPersianDigits(classAttendance.length)} جلسه ثبت شده
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs mb-2">
            <span>یادآوری‌های فعال</span>
            <Bell className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {toPersianDigits(activeReminders.length)}
            <span className="text-xs font-normal text-slate-400 ms-1">مورد</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            امتحانات و وظایف پیش‌رو
          </span>
        </div>
      </div>

      {/* 2-Column Split: Reminders & Attendance Task / Recent Student Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Reminders Card */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-500" />
              <span>یادآوری‌ها و وظایف آموزشی</span>
            </h3>
            <button
              onClick={() => setActiveTab('more')}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5"
            >
              <span>مشاهده همه</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          {upcomingReminders.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">
              هیچ یادآوری فعالی ثبت نشده است.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {upcomingReminders.map((rem) => (
                <div key={rem.id} className="py-2.5 flex items-start gap-3">
                  <button
                    onClick={() => toggleReminderComplete(rem.id)}
                    className="mt-0.5 w-5 h-5 rounded-md border border-slate-300 dark:border-slate-700 hover:border-emerald-500 flex items-center justify-center shrink-0 transition-colors"
                  >
                    {rem.completed && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block truncate">
                      {rem.title}
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      {toPersianDigits(rem.date)} · ساعت {toPersianDigits(rem.time)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Student Performance Highlights */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>دانش‌آموزان برتر و نیازمند توجه</span>
            </h3>
            <button
              onClick={() => setActiveTab('gradebook')}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5"
            >
              <span>ریز نمرات</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2">
            {topStudents.map((item, idx) => (
              <div
                key={item.student.id}
                onClick={() => setSelectedStudentProfileId(item.student.id)}
                className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 hover:bg-emerald-50/50 dark:hover:bg-slate-800 transition-colors flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-center">
                    {toPersianDigits(idx + 1)}
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                      {item.student.firstName} {item.student.lastName}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {toPersianDigits(item.grade?.positiveScores || 0)} نمره مثبت کلاسی
                    </span>
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 block tabular-nums">
                    {formatScore(item.score)}
                  </span>
                  <span className="text-[9px] text-emerald-700 dark:text-emerald-300">عالی</span>
                </div>
              </div>
            ))}

            {lowStudents.map((item) => (
              <div
                key={item.student.id}
                onClick={() => setSelectedStudentProfileId(item.student.id)}
                className="p-2.5 rounded-xl bg-rose-50/50 dark:bg-rose-950/20 hover:bg-rose-100/50 transition-colors flex items-center justify-between cursor-pointer border border-rose-100 dark:border-rose-900/30"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 h-6 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center justify-center">
                    !
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                      {item.student.firstName} {item.student.lastName}
                    </span>
                    <span className="text-[10px] text-rose-500">نیاز به تمرین ترمیمی</span>
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-rose-600 dark:text-rose-400 block tabular-nums">
                    {formatScore(item.score)}
                  </span>
                  <span className="text-[9px] text-rose-600">نیازمند تلاش</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
