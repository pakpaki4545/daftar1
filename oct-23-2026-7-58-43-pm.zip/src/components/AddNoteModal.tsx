import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, FileText } from 'lucide-react';
import { getTodayJalaliString } from '../utils/persian';
import { NoteCategory } from '../types';

interface AddNoteModalProps {
  onClose: () => void;
}

export const AddNoteModal: React.FC<AddNoteModalProps> = ({ onClose }) => {
  const { activeClass, addNote, showToast } = useApp();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoteCategory>('class');
  const [noteDate, setNoteDate] = useState(getTodayJalaliString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      showToast('عنوان و متن یادداشت را وارد فرمایید', 'error');
      return;
    }

    addNote({
      title: title.trim(),
      content: content.trim(),
      category,
      date: noteDate,
      classId: activeClass?.id,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-600" />
            <span>ثبت یادداشت جدید</span>
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">عنوان یادداشت *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثلاً: بودجه‌بندی تدریس فصل ۲..."
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-500 mb-1">دسته‌بندی</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as NoteCategory)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
              >
                <option value="class">کلاسی</option>
                <option value="curriculum">بودجه‌بندی تدریس</option>
                <option value="student">ویژه دانش‌آموز</option>
                <option value="school">امور مدرسه</option>
                <option value="personal">شخصی معلم</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-500 mb-1">تاریخ (شمسی)</label>
              <input
                type="text"
                value={noteDate}
                onChange={(e) => setNoteDate(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">متن یادداشت *</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="متن کامل یادداشت یا نکات تدریس..."
              rows={4}
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none leading-relaxed"
              required
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100"
            >
              انصراف
            </button>
            <button
              type="submit"
              className="px-5 py-2 font-medium bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
            >
              ذخیره یادداشت
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
