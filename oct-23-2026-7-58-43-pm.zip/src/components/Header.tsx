import React from 'react';
import { useApp } from '../context/AppContext';
import { BookOpen, Moon, Sun, Download, GraduationCap, ChevronDown } from 'lucide-react';
import { getTodayJalaliFormatted, toPersianDigits } from '../utils/persian';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenInstall: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings, onOpenInstall }) => {
  const { classes, activeClassId, setActiveClassId, activeClass, isDarkMode, toggleDarkMode, exportClassGradesToCSV } = useApp();
  const today = getTodayJalaliFormatted();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center shadow-sm">
            <BookOpen className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-base leading-tight text-slate-900 dark:text-white">
              دفتر نمره
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              {today.fullString}
            </span>
          </div>
        </div>

        {/* Center / Class Switcher Zone */}
        <div className="flex items-center gap-2 max-w-xs md:max-w-md w-full justify-center">
          {classes.length > 0 && (
            <div className="relative w-full max-w-[220px]">
              <select
                value={activeClassId}
                onChange={(e) => setActiveClassId(e.target.value)}
                className="w-full appearance-none bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs md:text-sm font-medium py-1.5 pe-8 ps-3 rounded-lg border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer truncate"
              >
                {classes.map((cls) => (
                  <option key={cls.id} value={cls.id}>
                    {cls.name} ({cls.subject})
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute end-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          )}
        </div>

        {/* Actions Zone */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onOpenInstall}
            title="نصب برنامه روی گوشی"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">نصب روی گوشی</span>
            <span className="sm:hidden">نصب</span>
          </button>

          {activeClass && (
            <button
              onClick={() => exportClassGradesToCSV(activeClass.id)}
              title="دریافت فایل اکسل این کلاس"
              aria-label="دریافت اکسل"
              className="hidden md:flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>اکسل</span>
            </button>
          )}

          <button
            onClick={toggleDarkMode}
            title={isDarkMode ? 'حالت روز' : 'حالت شب'}
            aria-label="تغییر تم"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenSettings}
            title="پشتیبان‌گیری و تنظیمات"
            aria-label="تنظیمات"
            className="px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors shrink-0"
          >
            تنظیمات
          </button>
        </div>
      </div>
    </header>
  );
};
