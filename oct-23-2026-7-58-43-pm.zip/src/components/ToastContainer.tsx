import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-20 start-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 max-w-sm w-full px-4 pointer-events-none">
      {toasts.map((toast) => {
        let Icon = CheckCircle2;
        let style = 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900';
        if (toast.type === 'error') {
          Icon = AlertCircle;
          style = 'bg-rose-600 text-white';
        } else if (toast.type === 'info') {
          Icon = Info;
          style = 'bg-sky-600 text-white';
        }

        return (
          <div
            key={toast.id}
            className={`flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg shadow-black/10 text-xs md:text-sm font-medium animate-in fade-in slide-in-from-top-2 duration-200 pointer-events-auto ${style}`}
          >
            <Icon className="w-4 h-4 shrink-0" />
            <span className="flex-1 text-right">{toast.message}</span>
          </div>
        );
      })}
    </div>
  );
};
