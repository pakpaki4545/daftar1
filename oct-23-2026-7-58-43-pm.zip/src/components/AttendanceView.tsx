import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CalendarCheck,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  History,
  Trash2,
  Edit2,
  Calendar,
  Save,
  ChevronDown,
  Check,
  Search,
  UserCheck,
} from 'lucide-react';
import { getCurrentPersianTimeString, getTodayJalaliString, toPersianDigits } from '../utils/persian';
import { AttendanceStatus } from '../types';

interface AttendanceViewProps {
  initialOpenNewSession?: boolean;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({ initialOpenNewSession = false }) => {
  const {
    students,
    activeClass,
    attendance,
    addAttendanceSession,
    updateAttendanceSession,
    deleteAttendanceSession,
    setSelectedStudentProfileId,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'record' | 'history' | 'stats'>(
    initialOpenNewSession ? 'record' : 'history'
  );

  // New session state
  const [sessionDate, setSessionDate] = useState(getTodayJalaliString());
  const [sessionTime, setSessionTime] = useState(getCurrentPersianTimeString());
  const [sessionTopic, setSessionTopic] = useState('');
  const [sessionNotes, setSessionNotes] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);

  const classStudents = students.filter((s) => s.classId === activeClass?.id);

  // Initial student records map (default present)
  const [records, setRecords] = useState<Record<string, AttendanceStatus>>(() => {
    const init: Record<string, AttendanceStatus> = {};
    classStudents.forEach((s) => {
      init[s.id] = 'present';
    });
    return init;
  });

  const [searchStudent, setSearchStudent] = useState('');

  if (!activeClass) {
    return (
      <div className="p-8 text-center text-slate-500">
        لطفاً ابتدا یک کلاس ایجاد یا انتخاب نمایید.
      </div>
    );
  }

  const classSessions = attendance.filter((a) => a.classId === activeClass.id);

  // Toggle student status in current session
  const cycleStatus = (studentId: string) => {
    const current = records[studentId] || 'present';
    let next: AttendanceStatus = 'present';
    if (current === 'present') next = 'absent';
    else if (current === 'absent') next = 'late';
    else if (current === 'late') next = 'excused';
    else if (current === 'excused') next = 'present';

    setRecords((prev) => ({ ...prev, [studentId]: next }));
  };

  const markAllPresent = () => {
    const updated: Record<string, AttendanceStatus> = {};
    classStudents.forEach((s) => {
      updated[s.id] = 'present';
    });
    setRecords(updated);
    showToast('همه دانش‌آموزان حاضر ثبت شدند');
  };

  const handleSaveSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSessionId) {
      updateAttendanceSession(editingSessionId, {
        date: sessionDate,
        time: sessionTime,
        topic: sessionTopic.trim(),
        notes: sessionNotes.trim(),
        records,
      });
      setEditingSessionId(null);
    } else {
      addAttendanceSession({
        classId: activeClass.id,
        date: sessionDate,
        time: sessionTime,
        topic: sessionTopic.trim(),
        notes: sessionNotes.trim(),
        records,
      });
    }

    setActiveTab('history');
    setSessionTopic('');
    setSessionNotes('');
  };

  const handleEditPastSession = (sessionId: string) => {
    const session = classSessions.find((s) => s.id === sessionId);
    if (!session) return;
    setEditingSessionId(session.id);
    setSessionDate(session.date);
    setSessionTime(session.time);
    setSessionTopic(session.topic || '');
    setSessionNotes(session.notes || '');
    setRecords(session.records);
    setActiveTab('record');
  };

  const handleNewSessionClick = () => {
    setEditingSessionId(null);
    setSessionDate(getTodayJalaliString());
    setSessionTime(getCurrentPersianTimeString());
    setSessionTopic('');
    setSessionNotes('');
    const init: Record<string, AttendanceStatus> = {};
    classStudents.forEach((s) => {
      init[s.id] = 'present';
    });
    setRecords(init);
    setActiveTab('record');
  };

  // Counts for current record form
  let curPresent = 0;
  let curAbsent = 0;
  let curLate = 0;
  let curExcused = 0;
  classStudents.forEach((s) => {
    const st = records[s.id] || 'present';
    if (st === 'present') curPresent++;
    else if (st === 'absent') curAbsent++;
    else if (st === 'late') curLate++;
    else if (st === 'excused') curExcused++;
  });

  const filteredClassStudents = classStudents.filter((s) => {
    if (!searchStudent.trim()) return true;
    const name = `${s.firstName} ${s.lastName}`.toLowerCase();
    return name.includes(searchStudent.toLowerCase().trim());
  });

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
        <div>
          <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-teal-600" />
            <span>حضور و غیاب هوشمند: {activeClass.name}</span>
          </h1>
          <p className="text-xs text-slate-500">
            ثبت سریع وضعیت با یک لمس، محاسبه ساعات غیبت موجه/غیرموجه و تاریخچه جلسات
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab !== 'record' ? (
            <button
              onClick={handleNewSessionClick}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>ثبت جلسه جدید امروز</span>
            </button>
          ) : (
            <button
              onClick={() => setActiveTab('history')}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl transition-colors"
            >
              مشاهده سوابق جلسات
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('record')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            activeTab === 'record'
              ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          {editingSessionId ? 'ویرایش جلسه' : 'ثبت حضور و غیاب جلسه'}
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            activeTab === 'history'
              ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          تاریخچه جلسات ({toPersianDigits(classSessions.length)})
        </button>
        <button
          onClick={() => setActiveTab('stats')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
            activeTab === 'stats'
              ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          آمار و غیبت‌های دانش‌آموزان
        </button>
      </div>

      {/* Tab 1: Record / Take Attendance Screen */}
      {activeTab === 'record' && (
        <form onSubmit={handleSaveSession} className="space-y-4">
          {/* Session Info Bar */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-slate-500 mb-1">تاریخ جلسه (شمسی)</label>
                <input
                  type="text"
                  value={sessionDate}
                  onChange={(e) => setSessionDate(e.target.value)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">ساعت کلاس</label>
                <input
                  type="text"
                  value={sessionTime}
                  onChange={(e) => setSessionTime(e.target.value)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">موضوع تدریس / درس این جلسه</label>
                <input
                  type="text"
                  value={sessionTopic}
                  onChange={(e) => setSessionTopic(e.target.value)}
                  placeholder="مثلاً: فصل دوم مبحث گوارش در معده..."
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
                />
              </div>
            </div>

            {/* Live Counter & Fast Mark Button */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-600 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{toPersianDigits(curPresent)} حاضر</span>
                </span>
                <span className="flex items-center gap-1 text-rose-600 font-bold">
                  <XCircle className="w-4 h-4" />
                  <span>{toPersianDigits(curAbsent)} غایب</span>
                </span>
                <span className="flex items-center gap-1 text-amber-600 font-bold">
                  <Clock className="w-4 h-4" />
                  <span>{toPersianDigits(curLate)} تأخیر</span>
                </span>
                <span className="flex items-center gap-1 text-sky-600 font-bold">
                  <AlertCircle className="w-4 h-4" />
                  <span>{toPersianDigits(curExcused)} موجه</span>
                </span>
              </div>

              <button
                type="button"
                onClick={markAllPresent}
                className="px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 rounded-xl border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
              >
                علامت‌گذاری همه به عنوان حاضر
              </button>
            </div>
          </div>

          {/* Quick Filter Search for large classes */}
          {classStudents.length > 8 && (
            <div className="relative">
              <input
                type="text"
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                placeholder="جستجوی سریع نام دانش‌آموز..."
                className="w-full text-xs py-2 ps-8 pe-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2" />
            </div>
          )}

          {/* Rapid Touch List of Students */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {filteredClassStudents.map((student, idx) => {
              const status = records[student.id] || 'present';
              let statusText = 'حاضر';
              let statusBg = 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300';
              let badgeColor = 'bg-emerald-600 text-white';

              if (status === 'absent') {
                statusText = 'غایب';
                statusBg = 'bg-rose-50 border-rose-200 text-rose-800 dark:bg-rose-950/40 dark:border-rose-800 dark:text-rose-300';
                badgeColor = 'bg-rose-600 text-white';
              } else if (status === 'late') {
                statusText = 'تأخیر';
                statusBg = 'bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-950/40 dark:border-amber-800 dark:text-amber-300';
                badgeColor = 'bg-amber-600 text-white';
              } else if (status === 'excused') {
                statusText = 'موجه';
                statusBg = 'bg-sky-50 border-sky-200 text-sky-800 dark:bg-sky-950/40 dark:border-sky-800 dark:text-sky-300';
                badgeColor = 'bg-sky-600 text-white';
              }

              return (
                <div
                  key={student.id}
                  onClick={() => cycleStatus(student.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer select-none active:scale-[0.98] flex items-center justify-between ${statusBg}`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-white/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center justify-center shrink-0">
                      {toPersianDigits(idx + 1)}
                    </span>
                    <div>
                      <span className="text-xs font-bold block">
                        {student.firstName} {student.lastName}
                      </span>
                      <span className="text-[10px] opacity-70">
                        {toPersianDigits(student.nationalCode) || 'دانش‌آموز'}
                      </span>
                    </div>
                  </div>

                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-xl shadow-xs ${badgeColor}`}>
                    {statusText}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Notes on session */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              یادداشت یا رویداد کلاسی این جلسه (اختیاری)
            </label>
            <textarea
              value={sessionNotes}
              onChange={(e) => setSessionNotes(e.target.value)}
              placeholder="مثلاً: پرسش کلاسی انجام شد، تمرین‌های درس ۲ بررسی شد، تاخیر دانش‌آموز..."
              rows={2}
              className="w-full text-xs p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none"
            />
          </div>

          {/* Sticky Save CTA */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className="px-4 py-2.5 text-xs text-slate-600 rounded-xl hover:bg-slate-100"
            >
              انصراف
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{editingSessionId ? 'ذخیره تغییرات جلسه' : 'ثبت قطعی جلسه حضور و غیاب'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Session History */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {classSessions.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              هنوز جلسه‌ای برای این کلاس ثبت نشده است. با دکمه «ثبت جلسه جدید» اولین جلسه را ثبت کنید.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs">
              {classSessions.map((sess) => {
                let p = 0;
                let a = 0;
                let l = 0;
                let ex = 0;
                Object.values(sess.records).forEach((st) => {
                  if (st === 'present') p++;
                  else if (st === 'absent') a++;
                  else if (st === 'late') l++;
                  else if (st === 'excused') ex++;
                });

                return (
                  <div key={sess.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs md:text-sm text-slate-800 dark:text-slate-100">
                          جلسه {toPersianDigits(sess.date)}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          ساعت {toPersianDigits(sess.time)}
                        </span>
                      </div>
                      {sess.topic && (
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          موضوع: {sess.topic}
                        </p>
                      )}
                      {sess.notes && (
                        <p className="text-[11px] text-slate-400">
                          یادداشت: {sess.notes}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3">
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="text-emerald-600 font-bold">{toPersianDigits(p)} حاضر</span>
                        {a > 0 && <span className="text-rose-600 font-bold">{toPersianDigits(a)} غایب</span>}
                        {l > 0 && <span className="text-amber-600 font-bold">{toPersianDigits(l)} تأخیر</span>}
                        {ex > 0 && <span className="text-sky-600 font-bold">{toPersianDigits(ex)} موجه</span>}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleEditPastSession(sess.id)}
                          className="p-1.5 text-slate-500 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="ویرایش این جلسه"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteAttendanceSession(sess.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="حذف این جلسه"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Attendance Statistics */}
      {activeTab === 'stats' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xs">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-bold text-xs md:text-sm text-slate-800 dark:text-slate-100">
                گزارش جامع غیبت‌ها و وضعیت حضور دانش‌آموزان
              </h2>
              <p className="text-[11px] text-slate-500">
                تعداد کل جلسات برگزار شده: {toPersianDigits(classSessions.length)} جلسه
              </p>
            </div>

            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300">
                <tr>
                  <th className="p-3">نام دانش‌آموز</th>
                  <th className="p-3 text-center">حاضر</th>
                  <th className="p-3 text-center">غیبت غیرموجه</th>
                  <th className="p-3 text-center">تأخیر</th>
                  <th className="p-3 text-center">غیبت موجه</th>
                  <th className="p-3 text-center">درصد حضور</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {classStudents.map((st) => {
                  let p = 0;
                  let a = 0;
                  let l = 0;
                  let ex = 0;
                  classSessions.forEach((sess) => {
                    const stStatus = sess.records[st.id] || 'present';
                    if (stStatus === 'present') p++;
                    else if (stStatus === 'absent') a++;
                    else if (stStatus === 'late') l++;
                    else if (stStatus === 'excused') ex++;
                  });
                  const total = p + a + l + ex;
                  const rate = total > 0 ? Math.round(((p + l * 0.75) / total) * 100) : 100;

                  return (
                    <tr
                      key={st.id}
                      onClick={() => setSelectedStudentProfileId(st.id)}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                    >
                      <td className="p-3 font-medium text-slate-800 dark:text-slate-200">
                        {st.firstName} {st.lastName}
                      </td>
                      <td className="p-3 text-center font-bold text-emerald-600">
                        {toPersianDigits(p)}
                      </td>
                      <td className="p-3 text-center font-bold text-rose-600">
                        {toPersianDigits(a)}
                      </td>
                      <td className="p-3 text-center font-bold text-amber-600">
                        {toPersianDigits(l)}
                      </td>
                      <td className="p-3 text-center font-bold text-sky-600">
                        {toPersianDigits(ex)}
                      </td>
                      <td className="p-3 text-center font-black">
                        <span className={rate >= 85 ? 'text-emerald-600' : rate >= 70 ? 'text-amber-600' : 'text-rose-600'}>
                          {toPersianDigits(rate)}٪
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
