import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  ActiveTab,
  AttendanceSession,
  AttendanceStatus,
  ClassRoom,
  CustomScore,
  GradingFormulaConfig,
  NoteItem,
  ReminderItem,
  Student,
  TermGradeRecord,
} from '../types';
import {
  INITIAL_ATTENDANCE,
  INITIAL_CLASSES,
  INITIAL_CUSTOM_SCORES,
  INITIAL_GRADES,
  INITIAL_NOTES,
  INITIAL_REMINDERS,
  INITIAL_STUDENTS,
} from '../data/initialData';
import { calculateAnnualScore, calculateTerm1Score, calculateTerm2Score, downloadCSV, formatScore, toPersianDigits } from '../utils/persian';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  classes: ClassRoom[];
  students: Student[];
  grades: TermGradeRecord[];
  customScores: CustomScore[];
  attendance: AttendanceSession[];
  notes: NoteItem[];
  reminders: ReminderItem[];
  activeClassId: string;
  setActiveClassId: (id: string) => void;
  activeClass?: ClassRoom;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectedStudentProfileId: string | null;
  setSelectedStudentProfileId: (id: string | null) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Class actions
  addClass: (cls: Omit<ClassRoom, 'id' | 'createdAt'>) => string;
  updateClass: (id: string, updates: Partial<ClassRoom>) => void;
  deleteClass: (id: string) => void;

  // Student actions
  addStudent: (student: Omit<Student, 'id' | 'createdAt'>) => string;
  batchAddStudents: (classId: string, studentLines: string) => number;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  // Grade actions
  updateTermGrade: (
    studentId: string,
    classId: string,
    field: 'continuousTerm1' | 'finalTerm1' | 'continuousTerm2' | 'finalTerm2',
    value: number | null
  ) => void;
  adjustPositiveScore: (studentId: string, classId: string, delta: number) => void;
  adjustNegativeScore: (studentId: string, classId: string, delta: number) => void;
  addCustomScore: (score: Omit<CustomScore, 'id'>) => void;
  deleteCustomScore: (id: string) => void;
  updateGradingFormula: (classId: string, config: GradingFormulaConfig) => void;

  // Attendance actions
  addAttendanceSession: (session: Omit<AttendanceSession, 'id' | 'createdAt'>) => string;
  updateAttendanceSession: (id: string, updates: Partial<AttendanceSession>) => void;
  deleteAttendanceSession: (id: string) => void;
  setStudentAttendance: (sessionId: string, studentId: string, status: AttendanceStatus) => void;

  // Note actions
  addNote: (note: Omit<NoteItem, 'id' | 'updatedAt'>) => void;
  updateNote: (id: string, updates: Partial<NoteItem>) => void;
  deleteNote: (id: string) => void;

  // Reminder actions
  addReminder: (reminder: Omit<ReminderItem, 'id' | 'createdAt'>) => void;
  updateReminder: (id: string, updates: Partial<ReminderItem>) => void;
  toggleReminderComplete: (id: string) => void;
  deleteReminder: (id: string) => void;

  // Data management
  exportBackupJSON: () => void;
  importBackupJSON: (jsonData: string) => boolean;
  resetToSampleData: () => void;
  exportClassGradesToCSV: (classId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CLASSES: 'daftarnomreh_classes_v1',
  STUDENTS: 'daftarnomreh_students_v1',
  GRADES: 'daftarnomreh_grades_v1',
  CUSTOM_SCORES: 'daftarnomreh_custom_scores_v1',
  ATTENDANCE: 'daftarnomreh_attendance_v1',
  NOTES: 'daftarnomreh_notes_v1',
  REMINDERS: 'daftarnomreh_reminders_v1',
  ACTIVE_CLASS: 'daftarnomreh_active_class_v1',
  THEME: 'daftarnomreh_theme_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [classes, setClasses] = useState<ClassRoom[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CLASSES);
      return saved ? JSON.parse(saved) : INITIAL_CLASSES;
    } catch {
      return INITIAL_CLASSES;
    }
  });

  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
    } catch {
      return INITIAL_STUDENTS;
    }
  });

  const [grades, setGrades] = useState<TermGradeRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GRADES);
      return saved ? JSON.parse(saved) : INITIAL_GRADES;
    } catch {
      return INITIAL_GRADES;
    }
  });

  const [customScores, setCustomScores] = useState<CustomScore[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOM_SCORES);
      return saved ? JSON.parse(saved) : INITIAL_CUSTOM_SCORES;
    } catch {
      return INITIAL_CUSTOM_SCORES;
    }
  });

  const [attendance, setAttendance] = useState<AttendanceSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
      return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
    } catch {
      return INITIAL_ATTENDANCE;
    }
  });

  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTES);
      return saved ? JSON.parse(saved) : INITIAL_NOTES;
    } catch {
      return INITIAL_NOTES;
    }
  });

  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REMINDERS);
      return saved ? JSON.parse(saved) : INITIAL_REMINDERS;
    } catch {
      return INITIAL_REMINDERS;
    }
  });

  const [activeClassId, setActiveClassId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_CLASS);
      return saved || (classes[0]?.id || 'class-1');
    } catch {
      return 'class-1';
    }
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [selectedStudentProfileId, setSelectedStudentProfileId] = useState<string | null>(null);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  // Sync with HTML class for dark mode
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem(STORAGE_KEYS.THEME, 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem(STORAGE_KEYS.THEME, 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CLASSES, JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GRADES, JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOM_SCORES, JSON.stringify(customScores));
  }, [customScores]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(reminders));
  }, [reminders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_CLASS, activeClassId);
  }, [activeClassId]);

  const activeClass = classes.find((c) => c.id === activeClassId) || classes[0];

  // Class actions
  const addClass = (cls: Omit<ClassRoom, 'id' | 'createdAt'>): string => {
    const newId = `class-${Date.now()}`;
    const newClass: ClassRoom = {
      ...cls,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    setClasses((prev) => [...prev, newClass]);
    setActiveClassId(newId);
    showToast(`کلاس «${newClass.name}» با موفقیت افزوده شد`);
    return newId;
  };

  const updateClass = (id: string, updates: Partial<ClassRoom>) => {
    setClasses((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    showToast('اطلاعات کلاس به‌روزرسانی شد');
  };

  const deleteClass = (id: string) => {
    setClasses((prev) => prev.filter((c) => c.id !== id));
    setStudents((prev) => prev.filter((s) => s.classId !== id));
    setGrades((prev) => prev.filter((g) => g.classId !== id));
    setAttendance((prev) => prev.filter((a) => a.classId !== id));
    setCustomScores((prev) => prev.filter((cs) => cs.classId !== id));
    const remaining = classes.filter((c) => c.id !== id);
    if (remaining.length > 0) {
      setActiveClassId(remaining[0].id);
    }
    showToast('کلاس و اطلاعات مربوطه با موفقیت حذف گردید');
  };

  // Student actions
  const addStudent = (studentData: Omit<Student, 'id' | 'createdAt'>): string => {
    const newId = `s-${Date.now()}`;
    const newStudent: Student = {
      ...studentData,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    setStudents((prev) => [...prev, newStudent]);

    // Create empty grade record
    const newGrade: TermGradeRecord = {
      id: `g-${Date.now()}`,
      studentId: newId,
      classId: studentData.classId,
      continuousTerm1: null,
      finalTerm1: null,
      continuousTerm2: null,
      finalTerm2: null,
      positiveScores: 0,
      negativeScores: 0,
      updatedAt: new Date().toISOString(),
    };
    setGrades((prev) => [...prev, newGrade]);
    showToast(`دانش‌آموز «${newStudent.firstName} ${newStudent.lastName}» افزوده شد`);
    return newId;
  };

  const batchAddStudents = (classId: string, studentLines: string): number => {
    const lines = studentLines.split('\n').map((l) => l.trim()).filter(Boolean);
    let count = 0;
    const newStudents: Student[] = [];
    const newGradeRecords: TermGradeRecord[] = [];

    lines.forEach((line, index) => {
      // Split by tab, comma, or space
      // Support formats like: "علی رضایی" or "علی, رضایی" or "1234567890, علی رضایی"
      const parts = line.split(/[,\t]+/).map((p) => p.trim()).filter(Boolean);
      let firstName = '';
      let lastName = '';
      let nationalCode = '';

      if (parts.length >= 3) {
        nationalCode = parts[0];
        firstName = parts[1];
        lastName = parts[2];
      } else if (parts.length === 2) {
        firstName = parts[0];
        lastName = parts[1];
      } else if (parts.length === 1) {
        const words = parts[0].split(/\s+/);
        if (words.length >= 2) {
          firstName = words[0];
          lastName = words.slice(1).join(' ');
        } else {
          firstName = words[0];
          lastName = '';
        }
      }

      if (firstName) {
        const studentId = `s-${Date.now()}-${index}`;
        newStudents.push({
          id: studentId,
          classId,
          nationalCode: nationalCode || String(Date.now()).slice(-8) + index,
          firstName,
          lastName,
          createdAt: new Date().toISOString(),
        });

        newGradeRecords.push({
          id: `g-${Date.now()}-${index}`,
          studentId,
          classId,
          continuousTerm1: null,
          finalTerm1: null,
          continuousTerm2: null,
          finalTerm2: null,
          positiveScores: 0,
          negativeScores: 0,
          updatedAt: new Date().toISOString(),
        });
        count++;
      }
    });

    if (count > 0) {
      setStudents((prev) => [...prev, ...newStudents]);
      setGrades((prev) => [...prev, ...newGradeRecords]);
      showToast(`${toPersianDigits(count)} دانش‌آموز با موفقیت وارد شدند`);
    }
    return count;
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    setStudents((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    showToast('اطلاعات دانش‌آموز به‌روزرسانی شد');
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
    setGrades((prev) => prev.filter((g) => g.studentId !== id));
    setCustomScores((prev) => prev.filter((cs) => cs.studentId !== id));
    showToast('دانش‌آموز از لیست حذف شد');
  };

  // Grade actions
  const updateTermGrade = (
    studentId: string,
    classId: string,
    field: 'continuousTerm1' | 'finalTerm1' | 'continuousTerm2' | 'finalTerm2',
    value: number | null
  ) => {
    setGrades((prev) => {
      const existing = prev.find((g) => g.studentId === studentId && g.classId === classId);
      if (existing) {
        return prev.map((g) =>
          g.studentId === studentId && g.classId === classId
            ? { ...g, [field]: value, updatedAt: new Date().toISOString() }
            : g
        );
      } else {
        const newRecord: TermGradeRecord = {
          id: `g-${Date.now()}`,
          studentId,
          classId,
          continuousTerm1: null,
          finalTerm1: null,
          continuousTerm2: null,
          finalTerm2: null,
          positiveScores: 0,
          negativeScores: 0,
          [field]: value,
          updatedAt: new Date().toISOString(),
        };
        return [...prev, newRecord];
      }
    });
  };

  const adjustPositiveScore = (studentId: string, classId: string, delta: number) => {
    setGrades((prev) => {
      const existing = prev.find((g) => g.studentId === studentId && g.classId === classId);
      if (existing) {
        const nextVal = Math.max(0, (existing.positiveScores || 0) + delta);
        return prev.map((g) =>
          g.studentId === studentId && g.classId === classId
            ? { ...g, positiveScores: nextVal, updatedAt: new Date().toISOString() }
            : g
        );
      } else {
        return [
          ...prev,
          {
            id: `g-${Date.now()}`,
            studentId,
            classId,
            continuousTerm1: null,
            finalTerm1: null,
            continuousTerm2: null,
            finalTerm2: null,
            positiveScores: Math.max(0, delta),
            negativeScores: 0,
            updatedAt: new Date().toISOString(),
          },
        ];
      }
    });
  };

  const adjustNegativeScore = (studentId: string, classId: string, delta: number) => {
    setGrades((prev) => {
      const existing = prev.find((g) => g.studentId === studentId && g.classId === classId);
      if (existing) {
        const nextVal = Math.max(0, (existing.negativeScores || 0) + delta);
        return prev.map((g) =>
          g.studentId === studentId && g.classId === classId
            ? { ...g, negativeScores: nextVal, updatedAt: new Date().toISOString() }
            : g
        );
      } else {
        return [
          ...prev,
          {
            id: `g-${Date.now()}`,
            studentId,
            classId,
            continuousTerm1: null,
            finalTerm1: null,
            continuousTerm2: null,
            finalTerm2: null,
            positiveScores: 0,
            negativeScores: Math.max(0, delta),
            updatedAt: new Date().toISOString(),
          },
        ];
      }
    });
  };

  const addCustomScore = (score: Omit<CustomScore, 'id'>) => {
    const newScore: CustomScore = {
      ...score,
      id: `cs-${Date.now()}`,
    };
    setCustomScores((prev) => [...prev, newScore]);
    showToast(`نمره فعالیت «${newScore.title}» ثبت شد`);
  };

  const deleteCustomScore = (id: string) => {
    setCustomScores((prev) => prev.filter((s) => s.id !== id));
    showToast('نمره فعالیت حذف شد');
  };

  const updateGradingFormula = (classId: string, config: GradingFormulaConfig) => {
    setClasses((prev) =>
      prev.map((c) => (c.id === classId ? { ...c, gradingConfig: config } : c))
    );
    showToast('فرمول محاسبه نمرات به‌روزرسانی گردید');
  };

  // Attendance actions
  const addAttendanceSession = (session: Omit<AttendanceSession, 'id' | 'createdAt'>): string => {
    const newId = `att-${Date.now()}`;
    const newSession: AttendanceSession = {
      ...session,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    setAttendance((prev) => [newSession, ...prev]);
    showToast('جلسه حضور و غیاب با موفقیت ثبت شد');
    return newId;
  };

  const updateAttendanceSession = (id: string, updates: Partial<AttendanceSession>) => {
    setAttendance((prev) => prev.map((a) => (a.id === id ? { ...a, ...updates } : a)));
    showToast('اطلاعات جلسه به‌روزرسانی شد');
  };

  const deleteAttendanceSession = (id: string) => {
    setAttendance((prev) => prev.filter((a) => a.id !== id));
    showToast('جلسه حضور و غیاب حذف گردید');
  };

  const setStudentAttendance = (sessionId: string, studentId: string, status: AttendanceStatus) => {
    setAttendance((prev) =>
      prev.map((session) => {
        if (session.id === sessionId) {
          return {
            ...session,
            records: {
              ...session.records,
              [studentId]: status,
            },
          };
        }
        return session;
      })
    );
  };

  // Notes
  const addNote = (note: Omit<NoteItem, 'id' | 'updatedAt'>) => {
    const newNote: NoteItem = {
      ...note,
      id: `note-${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    setNotes((prev) => [newNote, ...prev]);
    showToast('یادداشت جدید ذخیره شد');
  };

  const updateNote = (id: string, updates: Partial<NoteItem>) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n))
    );
    showToast('یادداشت به‌روزرسانی شد');
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('یادداشت حذف شد');
  };

  // Reminders
  const addReminder = (reminder: Omit<ReminderItem, 'id' | 'createdAt'>) => {
    const newRem: ReminderItem = {
      ...reminder,
      id: `rem-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setReminders((prev) => [newRem, ...prev]);
    showToast('یادآوری جدید افزوده شد');
  };

  const updateReminder = (id: string, updates: Partial<ReminderItem>) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    showToast('یادآوری به‌روز شد');
  };

  const toggleReminderComplete = (id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, completed: !r.completed } : r))
    );
  };

  const deleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
    showToast('یادآوری حذف شد');
  };

  // Data management
  const exportBackupJSON = () => {
    const backupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      classes,
      students,
      grades,
      customScores,
      attendance,
      notes,
      reminders,
    };
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `daftarnomreh_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('فایل پشتیبان با موفقیت دانلود شد');
  };

  const importBackupJSON = (jsonData: string): boolean => {
    try {
      const data = JSON.parse(jsonData);
      if (!data.classes || !Array.isArray(data.classes)) {
        showToast('قالب فایل پشتیبان نامعتبر است', 'error');
        return false;
      }
      setClasses(data.classes);
      if (Array.isArray(data.students)) setStudents(data.students);
      if (Array.isArray(data.grades)) setGrades(data.grades);
      if (Array.isArray(data.customScores)) setCustomScores(data.customScores);
      if (Array.isArray(data.attendance)) setAttendance(data.attendance);
      if (Array.isArray(data.notes)) setNotes(data.notes);
      if (Array.isArray(data.reminders)) setReminders(data.reminders);
      if (data.classes.length > 0) setActiveClassId(data.classes[0].id);
      showToast('اطلاعات با موفقیت بازیابی شد');
      return true;
    } catch {
      showToast('خطا در خواندن فایل پشتیبان', 'error');
      return false;
    }
  };

  const resetToSampleData = () => {
    setClasses(INITIAL_CLASSES);
    setStudents(INITIAL_STUDENTS);
    setGrades(INITIAL_GRADES);
    setCustomScores(INITIAL_CUSTOM_SCORES);
    setAttendance(INITIAL_ATTENDANCE);
    setNotes(INITIAL_NOTES);
    setReminders(INITIAL_REMINDERS);
    setActiveClassId('class-1');
    showToast('اطلاعات نمونه اولیه بازگردانی شد');
  };

  const exportClassGradesToCSV = (clsId: string) => {
    const cls = classes.find((c) => c.id === clsId) || activeClass;
    if (!cls) return;
    const classStudents = students.filter((s) => s.classId === cls.id);

    const headers = [
      'ردیف',
      'کد دانش‌آموزی',
      'نام',
      'نام خانوادگی',
      'مستمر نوبت اول',
      'پایانی نوبت اول',
      'نمره نوبت اول',
      'مستمر نوبت دوم',
      'پایانی نوبت دوم',
      'نمره سالانه',
      'تعداد مثبت',
      'تعداد منفی',
      'وضعیت'
    ];

    const rows = classStudents.map((s, idx) => {
      const g = grades.find((gr) => gr.studentId === s.id && gr.classId === cls.id);
      const t1 = calculateTerm1Score(g);
      const annual = calculateAnnualScore(g, cls.gradingConfig);
      const isPassing = annual !== null ? annual >= cls.gradingConfig.passingThreshold : null;
      const statusText = isPassing === null ? 'ثبت نشده' : isPassing ? 'قبول' : 'نیازمند تلاش';

      return [
        idx + 1,
        s.nationalCode || '',
        s.firstName,
        s.lastName,
        g?.continuousTerm1 ?? '',
        g?.finalTerm1 ?? '',
        t1 ?? '',
        g?.continuousTerm2 ?? '',
        g?.finalTerm2 ?? '',
        annual ?? '',
        g?.positiveScores ?? 0,
        g?.negativeScores ?? 0,
        statusText
      ];
    });

    downloadCSV(`دفتر_نمره_${cls.name.replace(/\s+/g, '_')}`, headers, rows);
    showToast(`فایل اکسل کلاس «${cls.name}» آماده شد`);
  };

  return (
    <AppContext.Provider
      value={{
        classes,
        students,
        grades,
        customScores,
        attendance,
        notes,
        reminders,
        activeClassId,
        setActiveClassId,
        activeClass,
        activeTab,
        setActiveTab,
        selectedStudentProfileId,
        setSelectedStudentProfileId,
        isDarkMode,
        toggleDarkMode,
        toasts,
        showToast,
        addClass,
        updateClass,
        deleteClass,
        addStudent,
        batchAddStudents,
        updateStudent,
        deleteStudent,
        updateTermGrade,
        adjustPositiveScore,
        adjustNegativeScore,
        addCustomScore,
        deleteCustomScore,
        updateGradingFormula,
        addAttendanceSession,
        updateAttendanceSession,
        deleteAttendanceSession,
        setStudentAttendance,
        addNote,
        updateNote,
        deleteNote,
        addReminder,
        updateReminder,
        toggleReminderComplete,
        deleteReminder,
        exportBackupJSON,
        importBackupJSON,
        resetToSampleData,
        exportClassGradesToCSV,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
